<?php
    session_start();
    $mysqli = new mysqli("localhost", "root", "", "viplab");
    
    if($mysqli === false){
        die("ERROR: Could not connect. " . $mysqli->connect_error);
    }
?>

<!DOCTYPE html>
<html>
<head>

    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
<?php     
    $sql = "SELECT * FROM lab";
    $result = $mysqli->query($sql);
 ?>

<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Address</th>
            <th>Number</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	
	<?php while ($row = $result->fetch_array()) { ?>
		<tr>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['address']; ?></td>
            <td><?php echo $row['number']; ?></td>
			<td>
				<a href="server.php?id=<?php echo $row['id']; ?>" class="edit_btn" >Edit</a>
			</td>
			<td>
				<a href="server.php?del=<?php echo $row['id']; ?>" class="del_btn">Delete</a>
			</td>
		</tr>
	<?php } ?>
</table>
	<form method="post" action="server.php" >
		<div class="input-group">
			<label>Name</label>
			<input type="text" name="name" value="">
		</div>
		<div class="input-group">
			<label>Address</label>
			<input type="text" name="address" value="">
		</div>
        <div class="input-group">
			<label>Number</label>
			<input type="text" name="number" value="">
		</div>
		<div class="input-group">
			<button class="btn" type="submit" name="save" >Save</button>
		</div>
	</form>
</body>
</html>