<!Doctype html>
<html>
<head>
<title>Diagnostic Centre</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="test.css">

</head>

<body>
<header>
<div class="logo">

<h1 class="logo-text"><span>NR</span>Diagnostic Centre</h1>


</div>

<ul class="nav">
<li><a href="afterhome.php">Home</a></li>
<li><a href="afterabout.php">About Us</a></li>
<li><a href="#">Service</a>
<ul>
<li><a href="aftertest.php">Test Information</a></li>
<li><a href="afterindex.php">Health Check Up Package</a></li>

</ul>
</li>
<li><a href="#">Find A Doctor</a>
<ul>
<li><a href="aftermedicine.php">Department Of Medicine</a></li>

<li><a href="afterneurology.php">Department Of Neurology</a></li>
<li><a href="afterent.php">Department Of ENT</a></li>
</ul>

</li>
<li><a href="afterappointment1.php">Online Appointment</a>


</li>

                       <li><a href="logout.php">Logout</a>
                       

                        </li>
                  

</ul>


</header>
<section id="p">
<h2 class="test"></h2>


</section>
<section id="p1">
<h2 class="test1">Welcome to NRDiagnostic Centre</h2>

</section>


<div id="text"> 
<h1 id="k">About NRDiagnostic Center</h1>

<p id="k1">NR Diagnostic Centre has been in existence since 2019. It is approved by concerned authorities like Directorate General of Health Services,
Dhaka City Corporation, Ministry of Environment, Ministry <br>of Health and Family Welfare, Bangladesh Atomic Energy Commission.<br><br>

 NR Diagnostic Centre prides itself on its commitment to the patients and is constantlystriving to <br>improve diagnostic performance and 
 heightened satisfaction of patients and physicians delight.<br><br>
Our Slogan is  <b>We are always ready for service</b> <br></p>
</body>
</html>