<?php
$conn = new mysqli("localhost","root","","healthinfo");

if($conn->connect_error){
	
	die("could not connect to the data".$conn->connect_error);
}
$result = array('error'=>false);
$action = '';
if(isset($_GET['action'])){
	
	$action = $_GET['action'];
}
if($action == 'read'){
	$sql = $conn->query("SELECT * FROM user");
	$users = array();
	while($row = $sql->fetch_assoc()){
		array_push($users, $row);
		
	}
	$result['user'] = $users;
}






	

$conn->close();





echo json_encode($result);
?>