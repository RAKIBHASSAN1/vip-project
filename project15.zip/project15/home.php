<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="home.css">

<link href="https://fonts.googleapis.com/css?family=Candal|Lora&display=swap" rel="stylesheet">
<title> 
    Diagnostic Centre
</title> 

</head>
<body>

<header>
<div class="logo">

<h1 class="logo-text"><span>NR</span>Diagnostic Centre</h1>
<h3>We are always ready for service</h3>

</div>

<ul class="nav" id="xp">
<li><a href="home.php">Home</a></li>
<li><a href="about.php">About Us</a></li>
<li><a href="#">Service</a>
<ul>
<li><a href="test.php">Test Information</a></li>
<li><a href="index.php">Health Check Up Package</a></li>

</ul>
</li>
<li class="menu_1"><a href="#">Find A Doctor</a>

<ul>
<li><a href="medicine.php">Department Of Medicine</a></li>
<li><a href="neurology.php">Department Of Neurology</a></li>
<li><a href="ent.php">Department Of ENT</a></li>
</ul>
</li>
<li><a href="appointment1.php">Online Appointment</a>


</li>

                       <li><a href="#">Login</a>
                       <ul>
                            <li><a href="login2.php">Admin Login</a></li>
                            

                      </ul>

                        </li>
                 

</ul>


</header>
<section id="title">

<h1></h1>

</section>

<section id="information">

<h1>Find Information</h1>
<form action="search.php" method="GET">
    <input type="text" name="query" placeholder="Search..." />
    <input type="submit" value="Search" class="button_1"/>
</form>


</section>

<section id="boxes">

<div class="box">
<h3>Services</h3>
<p>Laboratory services is most essential for proper diagnosis and managment of your health. These are an important way for your physician to determine what is happening on inside your body. The work done by the staff and doctors at NRDCL Laboratory Services enables your physician to diagnose and treat your medical condition. It is vital to many medical treatments and disease control, resulting in improved management of your health.</p>

<p>Our purpzose is to provide you with high quality care and treatment, while increasing choice and reducing waiting times. The NR Diagnostic Centre offers a full range of the latest diagnostic and therapeutic imaging technology to outpatients as well as on emergency basis.</p>

<p>Our Laboratory Services is a multi-disciplinary medical diagnostic laboratory. We provide community and hospital diagnostic services to physicians and patients in Dhaka including the surrounding areas and other major cities of Bangladesh.<p>
</div>
<div class="box1">
<h3>NR Diagnostic Center</h3>
<p>Feel free to contact us. We are ready to communicate with you.

45/2 Siddissory Road
Malibagh
Dhaka - 1017
Bangladesh</p>


</div>
<div class="box2">
<h3>Recent News</h3>
<p>PLATINUM True Digital Radiography & Fluoroscopy X-Ray- Asia's 1st unit introduced by NR Diagnostic Centre Limited</p>


</div>




</section>
<footer>
<p>Copyright © 2019 NR dioganistic Ltd. Developed by re Infotainment Ltd</p>
</footer>

</body>
</html>