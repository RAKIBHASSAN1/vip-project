<?php
session_start(); 
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"]=== true){
    header("location: index.php");
    exit;
}
$username = $password = $userError = $passError = '';
if(isset($_POST['sub'])){
  $username = $_POST['username']; $password = $_POST['password'];
  if(($username === 'admin' && $password === 'password')or($username === 'nahid' && $password === '123456')){
    $_SESSION['login'] = true; header('LOCATION:afterindex.php'); die();
  }
  if($username !== 'admin')$userError = 'Invalid Username';
  if($password !== 'password')$passError = 'Invalid Password';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet" href="login2.css">

    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Login</h2>
        <p>Please fill in your credentials to login.</p>
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group " >
                <label>Username</label>
                <input type="text" name="username" class="form-control" value="<?php echo $username;?>">
                <span class="help-block"><?php echo $userError;?></span>
            </div>    
            <div class="form-group ">
                <label>Password</label>
                <input type="password" name="password" class="form-control" value="<?php echo $password;?>">
                <span class="help-block"><?php echo $passError;?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login" name="sub">
            </div>
           

        </form>
    </div>    
</body>
</html>