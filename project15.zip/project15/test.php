<!DOCTYPE html>
<html>

   <head>

   <meta charset="UTF-8">
  <meta name="description" content="Free Web tutorials">
  <meta name="keywords" content="HTML,CSS,XML,JavaScript">
  <meta name="author" content="John Doe">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  
  
  
      <title>Text Input Control</title>
	  
	  
	  
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
	  integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
      
		 
		   <link rel="stylesheet" href="home.css">
<link rel="stylesheet" href="test.css">
   </head>
   <header>
<div class="logo">

<h1 class="logo-text"><span>NR</span>Diagnostic Centre</h1>


</div>

<ul class="nav">
<li><a href="home.php">Home</a></li>
<li><a href="about.php">About Us</a></li>
<li><a href="#">Service</a>
<ul>
<li><a href="test.php">Test Information</a></li>
<li><a href="index.php">Health Check Up Package</a></li>

</ul>
</li>
<li><a href="#">Find A Doctor</a>
<ul>
<li><a href="medicine.php">Department Of Medicine</a></li>

<li><a href="neurology.php">Department Of Neurology</a></li>
<li><a href="ent.php">Department Of ENT</a></li>
</ul>

</li>
<li><a href="appointment1.php">Online Appointment</a>


</li>
<li><a href="#">Login</a>
<ul>
<li><a href="login2.php">Admin Login</a></li>



</ul>

</li>

</ul>


</header>
<section>
<h2 class="test"></h2>


</section>

<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  color:blue;
}
th, td {
  padding: 5px;
  text-align: left;
  font-size:20px;
}

</style>
</head>
<body>

<h1>Test Information And Price</h1>


<table style="width:100%">
 
  <tr>
    <th>Test Name</th>
    <th>Price</th>
  </tr>
  <tr>
    <td>CBC</td>
    <td>500</td>
  </tr>
  <tr>
    <td>FBS</td>
    <td>150</td>
  </tr>
  <tr>
    <td>Fasting Lipid Profile</td>
    <td>1000</td>
  </tr>
  <tr>
    <td>HBs Ag</td>
    <td>900</td>
  </tr>
  <tr>
    <td>SGPT (ALT)</td>
    <td>400</td>
  </tr>
  <tr>
    <td>Serum Creatinine</td>
    <td>300</td>
  </tr>
  <tr>
    <td>Urine R/M/R</td>
    <td>800</td>
  </tr>
  <tr>
    <td>X-Ray</td>
    <td>350</td>
  </tr>
  <tr>
    <td>TSH</td>
    <td>750</td>
  </tr>
  <tr>
    <td>ECG</td>
    <td>300</td>
  </tr>
  <tr>
    <td>SGOT</td>
    <td>500</td>
  </tr>
  <tr>
    <td>Echo</td>
    <td>900</td>
  </tr>
  
</table>

</body>
</html>
