<!DOCTYPE html>
<html>

   <head>

   <meta charset="UTF-8">
  <meta name="description" content="Free Web tutorials">
  <meta name="keywords" content="HTML,CSS,XML,JavaScript">
  <meta name="author" content="John Doe">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  
  
  
      <title>Text Input Control</title>
	  
	  
	  
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
	  integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
      
		 
		   <link rel="stylesheet" href="home.css">
<link rel="stylesheet" href="test.css">
   </head>
   <header>
<div class="logo">

<h1 class="logo-text"><span>NR</span>Diagnostic Centre</h1>


</div>

<ul class="nav">
<li><a href="home.php">Home</a></li>
<li><a href="about.php">About Us</a></li>
<li><a href="#">Service</a>
<ul>
<li><a href="test.php">Test Information</a></li>
<li><a href="index.php">Health Check Up Package</a></li>

</ul>
</li>
<li><a href="#">Find A Doctor</a>
<ul>
<li><a href="medicine.php">Department Of Medicine</a></li>

<li><a href="neurology.php">Department Of Neurology</a></li>
<li><a href="ent.php">Department Of ENT</a></li>
</ul>

</li>
<li><a href="appointment1.php">Online Appointment</a>


</li>
<li><a href="#">Login</a>
<ul>
<li><a href="login2.php">Admin Login</a></li>



</ul>

</li>

</ul>


</header>
<section>
<h2 class="test"></h2>


</section>
   
   <div id="app">
   <div class="container-fluid">
    <div class="row bg-dark">
	 <div class="col-lg-12">
	 <p class="text-center text-light display-4 pt-2" style="font-size:25px;">Health Check up package</p>
	 </div>
	</div>
   </div>
   
    <div class="container">
	<div class="row mt-3">
	<div class="col-lg-6">
	
	</div>
	<div class="col-lg-6">
	
	</div>
	
	</div>
	<hr class="bg-info">
	<div class="alert alert-danger" v-if="errorMsg">
	{{errorMsg}}
	</div>
	<div class="alert alert-success" v-if="successMsg">
	{{successMsg}}
	</div>
	<!--Display-->
	<div class="row">
		<div class="col-lg-12">
			<table class="table table-bordered table-striped">
			
			<thead>
			<tr class="text-center bg-info text-light">
			<th>Code</th>
			<th>Package Name</th>
			<th>Package Rate</th>
			<th>Details</th>
			
	
			</tr>
			
			</thead>
			<tbody>
			<tr class="text-center" v-for="user in user">
			
				<th>{{user.code}}</th>
			<th>{{user.name}}</th>
			<th>{{user.rate}}</th>
			<th>{{user.details}}</th>
			
			
			
			<tr>
			
			</tbody>
			</table>
		
		</div>
	
	</div>
	
	</div>
		
   <body>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.0/axios.min.js"></script>
	
    <script src="https://cdn.jsdelivr.net/npm/vue"></script>
	<script >
	var app = new Vue({
	
	el: '#app',
	data: {
		errorMsg: "",
		successMsg: "",
		showAddModal:false,
		showEditModal:false,
		
		
		user: [],
		
		newUser: {code: "",name: "",rate: "",details: ""},
		currentUser: {}
	},
	mounted: function(){
		this.getAllUsers();
	},
	methods: {
		getAllUsers(){
			
			axios.get("http://localhost/project15/process.php?action=read").then(function(response){
				
				if(response.data.error){
					app.errorMsg = response.data.message;
					
				}
				else{
					app.user =response.data.user;
				}
			});
		},
	
		
	}
})
	</script>
   </body>
	
</html>