
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$mysqli = new mysqli("localhost", "root", "", "appointment");

$limit = 2;
$timeArray = array("06:00 PM","06:30 PM","07:00 PM","07:30 PM","08:00 PM","08:30 PM","09:00 PM","09:30 PM","10:00 PM","10:30 PM");
$roomArray = array("401","402","403","404","405");
$drArray = array("Dr. Md. Amjad Hossain","Dr. Ikbal Hasan","Dr. Soriful Islam","Dr. Mobarak Hossain","Dr. Abul Kalam",);
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
 


//Checking limitation
if (isset($_POST['upload'])){
	$n = $mysqli->real_escape_string($_REQUEST['username']);
	$e = $mysqli->real_escape_string($_REQUEST['usermail']);
	$p = $mysqli->real_escape_string($_REQUEST['phone']);
	$a = $mysqli->real_escape_string($_REQUEST['address']);
	$do = $mysqli->real_escape_string($_REQUEST['doctor']);
	$d = $mysqli->real_escape_string($_REQUEST['select_date']);

$link = mysql_connect("localhost", "root", "");
mysql_select_db("appointment", $link);

$result = mysql_query("SELECT * FROM table1 WHERE Doctor = '$do' AND Date = '$d'", $link);
$limitSize = mysql_num_rows($result);

$serial = $limitSize;

if($limitSize>=$limit){
	echo "Sorry, Limit is full. Please try another date.";
}
else{
	//Attempt insert query execution
	$sql = "INSERT INTO table1 (Name,Email,Phone,Address,Doctor,Date) VALUES ('$n', '$e', '$p', '$a','$do','$d')";
	
	if(mysqli_query($mysqli, $sql)){
		$serial++;
		$time = $timeArray[$serial-1];
		
		$room = "401";  //Default value for initialization.
		
		for($i=0;$i<5;$i++){
			if($do == $drArray[$i])
				$room = $roomArray[$i];
		}

        $msg="Doctor Name: $do \nDate: $d \nSerial No: $serial \nTime: $time \nRoom No: $room";
        $to = $e;
        $subject = "Appointment Confimation";
        $mailheader = "From: nahid5533@gmail.com \r\n";
        mail($to, $subject, $msg, $mailheader) or die("Error!");
		
		echo "Thank You For Your Request. Check your email for confirmation message.";
	}
	else{
		echo "Something Wrong Please Try Again. " . mysqli_error($mysqli);
	}
}


// Close connection
mysqli_close($mysqli);
}
if (isset($_POST['update'])){
$n = $mysqli->real_escape_string($_REQUEST['username']);
$e = $mysqli->real_escape_string($_REQUEST['usermail']);
$p = $mysqli->real_escape_string($_REQUEST['phone']);
$a = $mysqli->real_escape_string($_REQUEST['address']);
$do = $mysqli->real_escape_string($_REQUEST['doctor']);
$d = $mysqli->real_escape_string($_REQUEST['select_date']);
$link = mysql_connect("localhost", "root", "");
mysql_select_db("appointment", $link);

$result = mysql_query("SELECT * FROM table1 WHERE Doctor = '$do' AND Date = '$d'", $link);
$limitSize = mysql_num_rows($result);

$serial = $limitSize;

if($limitSize>=$limit){
	echo "Sorry, Limit is full. Please try another date.";
}
else{
	//Attempt insert query execution
	$sql1 = "UPDATE  table1 SET Email='$e',Phone='$p',Address='$a',Doctor='$do',Date='$d'  WHERE Name='$n'";

	
	if(mysqli_query($mysqli, $sql1)){
		$serial++;
		$time = $timeArray[$serial-1];
		
		$room = "401";  //Default value for initialization.
		
		for($i=0;$i<5;$i++){
			if($do == $drArray[$i])
				$room = $roomArray[$i];
		}

        $msg="Doctor Name: $do \nDate: $d \nSerial No: $serial \nTime: $time \nRoom No: $room";
        $to = $e;
        $subject = "Appointment Confimation";
        $mailheader = "From: nahid5533@gmail.com \r\n";
        mail($to, $subject, $msg, $mailheader) or die("Error!");
		
		echo "Thank You For Your Request. Check your email for confirmation message.";
	}
	else{
		echo "Something Wrong Please Try Again. " . mysqli_error($mysqli);
	}
}
  
    
   
mysqli_close($mysqli);
  
   
    }
    if (isset($_POST['delate'])){
      
      
  
		$n = $mysqli->real_escape_string($_REQUEST['username']);

      
      
      $sql2 = "DELETE FROM table1 WHERE Name='$n'";
      mysqli_query($mysqli, $sql2);
    
     
      }
?>
