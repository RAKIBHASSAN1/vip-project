


<!DOCTYPE html>
<html>
<head>
<title>Doctor Information</title>
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="test.css">


<link rel="stylesheet" href="doctorprofile.css">
<link rel="stylesheet" href="medicine.css">

</head>
<body>
<header>
<div class="logo">

<h1 class="logo-text"><span>NR</span>Diagnostic Centre</h1>


</div>

<ul class="nav">
<li><a href="home.php">Home</a></li>
<li><a href="about.php">About Us</a></li>
<li><a href="#">Service</a>
<ul>
<li><a href="test.php">Test Information</a></li>
<li><a href="index.php">Health Check Up Package</a></li>

</ul>
</li>
<li><a href="#">Find A Doctor</a>
<ul>
<li><a href="medicine.php">Department Of Medicine</a></li>
<li><a href="neurology.php">Department Of Neurology</a></li>
<li><a href="ent.php">Department Of ENT</a></li>
</ul>

</li>
<li><a href="appointment1.php">Online Appointment</a>

</li>

                       <li><a href="#">Login</a>
                       <ul>
                            <li><a href="login2.php">Admin Login</a></li>
                            

                      </ul>

                        </li>
                  

</ul>


</header>
<section id="p">
<h2 class="test"></h2>


</section>

<section id="information">

<h1>Find Information</h1>
<form action="neurologysearch.php" method="GET">
    <input type="text" name="query" placeholder="Search..." />
    <input type="submit" value="Search" class="button_1"/>
</form>


</section>
<section id="p9">
<h2 class="test9"><br><br><b>NEUROLOGY DOCTOR LIST</b></h2>

</section>





<div id="content"> 

<?php

$db = mysqli_connect("localhost", "root", "", "doctor1");
$sql = "SELECT * FROM name WHERE department_name='neurology' or department_name='Neurology'";
$result = mysqli_query($db, $sql);
while ($row = mysqli_fetch_array($result)){
echo "<div id='img_div'>";
echo "<img src='images/".$row['image']."'>";
echo "<b>Name : <b>".$row['name']."<br><br>";
echo "<b>Qualifications : <b>".$row['qualifications']."<br><br>";
echo "<b>Specialty : <b>".$row['specialty']."<br><br>";
echo "<b>Designation : <b>".$row['designation']."<br><br>";
echo "<b>Department Name : <b>".$row['department_name']."<br><br>";
echo "<b>Consulting Hour : <b>".$row['consulting_hour']."<br><br>";
echo "</div>";
}
?>
</div>




</body>

</html>