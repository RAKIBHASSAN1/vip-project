
<html>
<head>


<link href="http://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css" rel="Stylesheet" type="text/css" />
<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
<link rel="stylesheet" href="home.css">
<link rel="stylesheet" href="doctorprofile.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


  
 
  
  
</head>


<body>

<header>
<div class="logo">

<h1 class="logo-text"><span>NR</span>Diagnostic Centre</h1>


</div>

<ul class="nav">
<li><a href="afterhome.php">Home</a></li>
<li><a href="afterabout.php">About Us</a></li>
<li><a href="#">Service</a>
<ul>
<li><a href="aftertest.php">Test Information</a></li>
<li><a href="afterindex.php">Health Check Up Package</a></li>

</ul>
</li>
<li><a href="#">Find A Doctor</a>
<ul>
<li><a href="aftermedicine.php">Department Of Medicine</a></li>

<li><a href="afterneurology.php">Department Of Neurology</a></li>
<li><a href="afterent.php">Department Of ENT</a></li>
</ul>

</li>
<li><a href="afterappointment1.php">Online Appointment</a>


</li>
<li><a href="logout.php">Logout</a>


</li>

</ul>


</header>
<section>
<h2 class="test"></h2>


</section>


<div class="modal-dialog row bg-dark">
<div class="modal-content modal-body p-2">	

<div class="modal-body p-4">
 <div class="container-fluid ">

<form action="appointment.php" method="post">
<h3>Please Provide information</h3>

<div class="form-group text-center">
<input type="text" name="username"  class="from-control from-control-lg " placeholder="Enter Your Name" required >
</div>

<div class="form-group text-center">
<input type="email" name="usermail" class="from-control from-control-lg" placeholder="Enter Your Email" required>
</div>

<div class="form-group text-center">
<input type="tel" id="phone" name="phone" class="from-control from-control-lg" pattern="[0-9]{11}" minlength="11" maxlength="11"  placeholder="Enter Contact Number" required>
</div>

<div class="form-group text-center">
<input type="text" name="address" class="from-control from-control-lg"  placeholder="Enter Your Address" required >
</div>
<div class="form-group text-center">

 <select id="doctor" name="doctor" class="from-control from-control-lg" placeholder="Select Doctor Name" required >
 <option value="">Please Select Doctor Name</option>
    <option value="Dr. Md. Amjad Hossain">Dr. Md. Amjad Hossain</option>
    <option value="Dr. Ikbal Hasan">Dr. Ikbal Hasan</option>
   
         <option value="Dr. Shoriful Islam">Dr. Soriful Islam</option>
          <option value="Dr. Mobarak Hossain">Dr. Mobarak Hossain</option>
          <option value="Dr. Abul Kalam">Dr. Abul Kalam</option>
  </select>
</div>
<div class="form-group text-center">
<input type="text"  id="select_date" name="select_date"  class="from-control from-control-lg" placeholder="Select Appointment Date" required >


</div>

<div class="form-group text-center">
<input type="submit" name="upload" value="Add" class="btn btn-info btn-block btn-lg" @click="showAddModal=false;" id="ns">
<input type="submit" name="update" value="Update" class="btn btn-info btn-block btn-lg" @click="showAddModal=false;" id="ns1">
<input type="submit" name="delate" value="Delate" class="btn btn-info btn-block btn-lg" @click="showAddModal=false;" id="ns2">
</div>
</div>
</div>
</div>
 </div>
</form>
</form>
<script type="text/javascript">

    $(function(){
    $("#select_date").datepicker({  
    format:"yy/mm/dd",
    beforeShowDay: function(date) {
   var show = true;
   if(date.getDay()==5) show=false
   return [show];
   } ,

    autoclose:true,
    todayHighth:true,
     showOtherMonths: true,
        selectOtherMonths: true,
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,
    
        minDate:new Date()

        
        });
    

        });
       </script>  
       
     
</body>  


</html>