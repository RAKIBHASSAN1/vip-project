<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$mysqli = new mysqli("localhost", "root", "", "healthinfo");
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
if (isset($_POST['upload'])){

$n = $mysqli->real_escape_string($_REQUEST['code']);
$e = $mysqli->real_escape_string($_REQUEST['name']);
$p = $mysqli->real_escape_string($_REQUEST['rate']);
$d = $mysqli->real_escape_string($_REQUEST['details']);

// Attempt insert query execution
$sql = "INSERT INTO user ( code,name,rate,details) VALUES ('$n', '$e', '$p', '$d')";
mysqli_query($mysqli, $sql);

 
// Close connection
mysqli_close($mysqli);
}
if (isset($_POST['update'])){
    $n = $mysqli->real_escape_string($_REQUEST['code']);
    $e = $mysqli->real_escape_string($_REQUEST['name']);
    $p = $mysqli->real_escape_string($_REQUEST['rate']);
    $d = $mysqli->real_escape_string($_REQUEST['details']);
    
    
    $sql1 = "UPDATE  user SET name='$e',rate='$p',details='$d'  WHERE code='$n'";
    mysqli_query($mysqli, $sql1);
  
   
    }
    if (isset($_POST['delate'])){
      
      
  
        $n = $mysqli->real_escape_string($_REQUEST['code']);

      
      
      $sql2 = "DELETE FROM user WHERE code='$n'";
      mysqli_query($mysqli, $sql2);
    
     
      }
?>

<!DOCTYPE html>
<html>
<head>
<title>INSERT HEALTH CHECK UP VALUE</title>
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="test.css">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
	  integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
      
<link rel="stylesheet" href="doctorprofile.css">
<link rel="stylesheet" href="medicine.css">

</head>
<body>
<header>
<div class="logo">

<h1 class="logo-text"><span>NR</span>Diagnostic Centre</h1>


</div>

<ul class="nav" id="xp">
<li><a href="afterhome.php">Home</a></li>
<li><a href="afterabout.php">About Us</a></li>
<li><a href="#">Service</a>
<ul>
<li><a href="aftertest.php">Test Information</a></li>
<li><a href="afterindex.php">Health Check Up Package</a></li>

</ul>
</li>
<li><a href="#">Find A Doctor</a>
<ul>
<li><a href="aftermedicine.php">Department Of Medicine</a></li>
<li><a href="afterneurology.php">Department Of Neurology</a></li>
<li><a href="afterent.php">Department Of ENT</a></li>
</ul>

</li>
<li><a href="afterappointment1.php">Online Appointment</a>

</li>

                       <li><a href="logout.php">Logout</a>
                      

                        </li>
                 


</ul>


</header>
<section>
<h2 class="test"></h2>


</section>


	<div class="modal-dialog row bg-dark">
	<div class="modal-content modal-body p-2">	
	<h5 class="modal-title text-center  bg-white">INSERT HEALTH CHECK UP VALUE</h5>
	<div class="modal-body p-4">
	 <div class="container-fluid ">

	<form action="insertform.php" method="post" enctype="multipart/form-data">
	
	<div class="form-group text-center">
	<input type="text" name="code" class="from-control from-control-lg " placeholder="Enter Code" required >
	</div>
	
	<div class="form-group text-center">
	<input type="text" name="name" class="from-control from-control-lg" placeholder="Package Name" required>
	</div>
	
	<div class="form-group text-center">
	<input type="number" name="rate" class="from-control from-control-lg" placeholder="Rate" required>
	</div>
	
	<div class="form-group text-center">
	<input type="text" name="details" class="from-control from-control-lg" placeholder="Details" required >
	</div>
	
	<div class="form-group text-center">
    <input type="submit" name="upload" value="Add" class="btn btn-info btn-block btn-lg" @click="showAddModal=false;" id="ns">
<input type="submit" name="update" value="Update" class="btn btn-info btn-block btn-lg" @click="showAddModal=false;" id="ns1">
<input type="submit" name="delate" value="Delate" class="btn btn-info btn-block btn-lg" @click="showAddModal=false;" id="ns2">
  

	</div>
	</div>
	</div>
	</div>
	 </div>
	</form>

</body>
</html>