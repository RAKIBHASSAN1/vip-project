<?php
$msg= "";
if (isset($_POST['upload'])){
$target = "images/".basename($_FILES['image']['name']);
$db = mysqli_connect("localhost", "root", "", "doctor1");
$image = $_FILES['image']['name'];
$name = $_POST['name'];
$qualifications = $_POST['qualifications'];
$specialty = $_POST['specialty'];
$designation = $_POST['designation'];
$department_name = $_POST['department_name'];
$consulting_hour = $_POST['consulting_hour'];
$sql = "INSERT INTO name (name ,qualifications ,specialty,designation,department_name,consulting_hour,image ) VALUES ('$name' ,'$qualifications' ,'$specialty','$designation','$department_name','$consulting_hour','$image')";
mysqli_query($db, $sql);

if (move_uploaded_file($_FILES['image']['tmp_name'], $target)){
	$msg = "Image upload";
}
else{
$msg = "There was a problem uploading image";
}
}
if (isset($_POST['update'])){
    $target = "images/".basename($_FILES['image']['name']);
    $db = mysqli_connect("localhost", "root", "", "doctor1");
    $image = $_FILES['image']['name'];
    $name = $_POST['name'];
    $qualifications = $_POST['qualifications'];
    $specialty = $_POST['specialty'];
    $designation = $_POST['designation'];
    $department_name = $_POST['department_name'];
    $consulting_hour = $_POST['consulting_hour'];
    
    
    $sql1 = "UPDATE  name SET qualifications='$qualifications' ,specialty='$specialty',designation='$designation',department_name='$department_name',consulting_hour='$consulting_hour',image='$image'  WHERE name='$name' and department_name='$department_name'";
    mysqli_query($db, $sql1);
  
   
    }
    if (isset($_POST['delate'])){
      
      $db = mysqli_connect("localhost", "root", "", "doctor1");
  
      $name = $_POST['name'];
    
      $department_name = $_POST['department_name'];
      
      
      
      $sql2 = "DELETE FROM name WHERE name='$name' and department_name='$department_name'";
      mysqli_query($db, $sql2);
    
     
      }
?>

<!DOCTYPE html>
<html>
<head>
<title>Doctor Information</title>
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="test.css">


<link rel="stylesheet" href="doctorprofile.css">
<link rel="stylesheet" href="medicine.css">

</head>
<body>
<header>
<div class="logo">

<h1 class="logo-text"><span>NR</span>Diagnostic Centre</h1>


</div>

<ul class="nav">
<li><a href="afterhome.php">Home</a></li>
<li><a href="afterabout.php">About Us</a></li>
<li><a href="#">Service</a>
<ul>
<li><a href="aftertest.php">Test Information</a></li>
<li><a href="afterindex.php">Health Check Up Package</a></li>

</ul>
</li>
<li><a href="#">Find A Doctor</a>
<ul>
<li><a href="aftermedicine.php">Department Of Medicine</a></li>
<li><a href="afterneurology.php">Department Of Neurology</a></li>
<li><a href="afterent.php">Department Of ENT</a></li>
</ul>

</li>
<li><a href="afterappointment1.php">Online Appointment</a>

</li>

                       <li><a href="#">Login</a>
                       <ul>
                            <li><a href="login2.php">Admin Login</a></li>
                            <li><a href="login1.php">User Login</a></li>

                      </ul>

                        </li>
                  


</ul>


</header>
<section id="p">
<h2 class="test"></h2>


</section>

<section id="information">

<h1>Find Information</h1>
<form action="afterentsearch.php" method="GET">
    <input type="text" name="query" placeholder="Search..." />
    <input type="submit" value="Search" class="button_1"/>
</form>


</section>
<section id="p9">
<h2 class="test9"><br><br><b>ENT DOCTOR LIST</b></h2>

</section>




<div id="content"> 

<?php

$db = mysqli_connect("localhost", "root", "", "doctor1");
if($db === false){
    die("ERROR: Could not connect. " . $db->connect_error);
}
if(isset($_GET["query"])){
	$query = $_GET['query']; 

	$query = htmlspecialchars($query); 
	
	$sql = "SELECT * FROM name WHERE (name='$query') and (department_name='ent' or department_name='ENT') ";
    $result = mysqli_query($db, $sql);
    if($result->num_rows > 0){
        while ($row = mysqli_fetch_array($result)){
            echo "<div id='img_div'>";
            echo "<img src='images/".$row['image']."'>";
            echo "<b>Name : <b>".$row['name']."<br><br>";
            echo "<b>Qualifications : <b>".$row['qualifications']."<br><br>";
            echo "<b>Specialty : <b>".$row['specialty']."<br><br>";
            echo "<b>Designation : <b>".$row['designation']."<br><br>";
            echo "<b>Department Name : <b>".$row['department_name']."<br><br>";
            echo "<b>Consulting Hour : <b>".$row['consulting_hour']."<br><br>";
            echo "</div>";
            } 
    }
    
}
?>
</div>
<div class="form1">
<br>
<p id="op">Doctor Information</p>

<form method="post" action="afterentsearch.php" enctype="multipart/form-data">
<div id="h1">
<label for="name"><b>Name :<b></label>
<input type="name" name="name"  placeholder="Enter Name" required>
</div>
<div id="h2">
<label for="qualifications"><b>Qualifications :<b></label>
<input type="qualifications" name="qualifications"  placeholder="Enter Qualifications" required>
</div>
<div id="h3">
<label for="specialty"><b>Specialty :<b></label>
<input type="specialty" name="specialty"  placeholder="Enter Specialty" required>
</div>
<div id="h4">
<label for="designation"><b>Designation :<b></label>
<input type="designation" name="designation"  placeholder="Enter Designation" required>
</div>
<div id="h5">
<label for="department_name"><b>Department Name :<b></label>
<input type="department_name" name="department_name"  placeholder="Enter Department Name" required>
</div>
<div id="h6">
<label for="consulting_hour"><b>Consulting Hour :<b></label>
<input type="consulting_hour" name="consulting_hour"  placeholder="Enter Consulting Hour" required>
</div>

<div id="h7">
<label for="file"><b>Image :<b></label>
<input type="file" name="image">
</div>
<div id="h8">
<input type="submit" name="upload" value="Add" id="ns">
<input type="submit" name="update" value="Update" id="ns1">
<input type="submit" name="delate" value="Delate" id="ns2">
</div>
</form>
</div>

</body>

</html>