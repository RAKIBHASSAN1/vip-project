<?php require ('php_code.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>photogallery/uploadImage</title>
    <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>



<div class="design_menu">
    <div class="menu">
        <ul>
            <li> <a  href="home.php" >Home</a></li>
            <li> <a class="current" href="upload.php=">Upload</a></li>
            <li> <a href="contact.php">Contact Us</a></li>
            <li> <a href="adminlogin.php">Admin</a></li>
            <li> <a href="index.php">Logout</a></li>
        </ul>
    </div>
</div>


<div class="upload">
    <form action="" method="post" id="design_form" enctype="multipart/form-data">
        <h1>Upload Your Image</h1>

        <table id="design_table">

            <tr>
                <td><label for="email" style="font-weight: bold"> Email </label></td>
            </tr>
            <tr>
                <td><input type="email" name="email" placeholder="Enter your Email" required></td>
            </tr>

            <tr>
                <td><label for="category" style="font-weight: bold"> Category</label></td>
            </tr>
            <tr>
                <td><input type="text" name="category" placeholder="Enter Image category" required></td>
            </tr>

            <tr>
                <td><label for="description" style="font-weight: bold">Image Description</label></td>
            </tr>
            <tr>
                <td><textarea style="width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;" rows="5" placeholder="Say something about this image" name="image_text"> </textarea></td>
            </tr>

            <tr>
                <td><label for="image" style="font-weight: bold"> Select Your Image</label></td>
            </tr>
            <tr>
                <td><input type="file" name="image"  required></td>
            </tr>

            <tr>
                <td><input type="submit" name="upload" value="Upload" id="btn"></td>
            </tr>

        </table>
    </form>

</div>
</body>
</html>