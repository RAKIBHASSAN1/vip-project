<?php require ('php_code.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PhotoGallery/adminlogin</title>
    <link rel="stylesheet" href="style.css" type="text/css">
    <style>
        table{
            width: 50%;
            margin: 30px auto;
            border-collapse: collapse;
            text-align: left;
        }
        tr {
            border-bottom: 1px solid #cbcbcb;
        }
        th, td{
            border: none;
            height: 30px;
            padding: 2px;
        }
        tr:hover {
            background: #F5F5F5;
        }
        .del_btn {
            text-decoration: none;
            padding: 2px 5px;
            color: white;
            border-radius: 3px;
            background: red;
        }
    </style>
</head>
<body>
<div class="design_menu">
    <div class="menu">
        <ul>
            <li> <a  href="home.php" id="home">Home</a></li>
            <li> <a href="upload.php">Upload</a></li>
            <li> <a class="current" href="admin.php">Admin</a></li>
            <li> <a href="home.php">Logout</a></li>
        </ul>
    </div>
</div>

<h2 style="text-align: center">Register Information </h2>

<a href="admin.php" class="register_btn">Register Details</a>
<a href="image_details.php" class="uplodar_btn"> Image Details</a>

<?php $results = mysqli_query($db, "SELECT * FROM registration"); ?>

<?php if (isset($_SESSION['message'])): ?>
    <div class="msg">
        <?php
        echo $_SESSION['message'];
        unset($_SESSION['message']);
        ?>
    </div>
<?php endif ?>

<table>
    <thead>
    <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Contact</th>
        <th colspan="2">Action</th>
    </tr>
    </thead>

    <?php while ($row = mysqli_fetch_array($results)) { ?>
        <tr>
            <td><?php echo $row['first_name']; ?></td>
            <td><?php echo $row['last_name']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['contact']; ?></td>
            <td>
                <a href="php_code.php?del=<?php echo $row['id']; ?>" class="del_btn" onclick=" return confirm('Are you sure to delete this user?')">Delete</a>
            </td>
        </tr>
    <?php } ?>
</table>

</body>
</html>