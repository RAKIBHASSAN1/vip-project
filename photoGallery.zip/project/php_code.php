<?php

session_start();
$db = mysqli_connect('localhost', 'root', '', 'project');

// initialize variables
$first_name = "";
$last_name= "";
$email= "";
$password= "";
$contact= "";
$id = 0;
$update = false;

/*Register Information*/
if (isset($_POST['register'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $contact = $_POST['contact'];

    mysqli_query($db, "INSERT INTO registration (first_name, last_name, email, password, contact) VALUES ('$first_name', '$last_name', '$email', '$password', '$contact')");
    $_SESSION['message'] = "Now you are register.login to visit our website";
    header('location: index.php');
}

/*user Login*/
if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = mysqli_query($db,"SELECT * FROM registration WHERE email = '$email' && password = '$password'");
    $users = mysqli_fetch_assoc($result);
        if($users){

                header('Location:home.php');
        }
        else{
            echo "<span style='color: red'>Not Register</span>";
    }
}
/*Admin Login */
if(isset($_POST['adminlogin'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = mysqli_query($db,"SELECT * FROM admin WHERE email = '$email' && password = '$password'");
    $users = mysqli_fetch_assoc($result);
    if($users){

        header('Location:admin.php');
    }
    else{
        echo "<h3><span style=\"color: red\">Sorry! Only for Admin</span></h3>";
    }
}


/*Delete*/
if (isset($_GET['del'])) {
    $id = $_GET['del'];
    mysqli_query($db, "DELETE FROM registration WHERE id=$id");
    $_SESSION['message'] = "Information deleted!";
    header('location: admin.php');
}

/*Delete Image */
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($db, "DELETE FROM images WHERE id=$id");
    $_SESSION['message'] = " Image & Information are deleted!";
    header('location: image_details.php');
}

/*image upload*/
if (isset($_POST['upload'])) {

    // Get text
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $category = mysqli_real_escape_string($db, $_POST['category']);
    $image_text = mysqli_real_escape_string($db, $_POST['image_text']);

    // Get image name
    $image = $_FILES['image']['name'];

    // image file directory
    $target = "uploaded_image/" . basename($image);

    $sql = "INSERT INTO images (email, category, image_text, image) VALUES ('$email', '$category', '$image_text', '$image')";

    mysqli_query($db, $sql);


    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      header('location:home.php');
    } else {
        echo"Failed to upload";
    }
}