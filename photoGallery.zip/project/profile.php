<?php require ('php_code.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PhotoGallery/login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php $results = mysqli_query($db, "SELECT * FROM registration WHERE id=$id"); ?>

<?php while ($row = mysqli_fetch_array($results)) { ?>

    <p><?php echo $row['first_name']; ?></p>
    <p><?php echo $row['last_name']; ?></p>
    <p><?php echo $row['email']; ?></p>
    <p><?php echo $row['password']; ?></p>
    <p><?php echo $row['contact']; ?></p>
<?php } ?>

<!--<table>
    <thead>
    <tr>
        <th>Name</th>
        <th>Address</th>
        <th colspan="2">Action</th>
    </tr>
    </thead>

    <?php /*while ($row = mysqli_fetch_array($results)) { */?>
        <tr>
            <td><?php /*echo $row['name']; */?></td>
            <td><?php /*echo $row['address']; */?></td>
            <td>
                <a href="index.php?edit=<?php /*echo $row['id']; */?>" class="edit_btn" >Edit</a>
            </td>
            <td>
                <a href="php_code.php?del=<?php /*echo $row['id']; */?>" class="del_btn">Delete</a>
            </td>
        </tr>
    <?php /*} */?>
</table>-->





</body>
</html>