<?php require ('php_code.php')?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PhotoGallery/login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>


<div class="login_form">
    <form action="php_code.php" method="post" id="design_form">
        <h1>Register Here</h1>
        <p style="font-weight: bold">Please fill in this form to sign in your account.</p>
        <table id="design_table">
            <tr>
                <td><label for="firstname" style="font-weight: bold">First Name</label></td>
            </tr>
            <tr>
                <td><input type="text" name="first_name" placeholder="Enter First Name" required></td>
            </tr>

            <tr>
                <td><label for="lastname" style="font-weight: bold">Last Name</label></td>
            </tr>
            <tr>
                <td><input type="text" name="last_name" placeholder="Enter Last Name" required></td>
            </tr>

            <tr>
                <td><label for="email" style="font-weight: bold">Email</label></td>
            </tr>
            <tr>
                <td><input type="email" name="email" placeholder="Enter Email" required></td>
            </tr>

            <tr>
                <td><label for="password" style="font-weight: bold">Password</label></td>
            </tr>
            <tr>
                <td><input type="password" name="password" placeholder="Enter Password" required></td>
            </tr>

            <tr>
                <td><label for="contact" style="font-weight: bold">Contact</label></td>
            </tr>
            <tr>
                <td><input type="text" name="contact" placeholder="Enter Your Contact Information" required></td>
            </tr>

            <tr>
                <td><input type="submit" name="register" value="Register" id="btn"></td>
            </tr>
            <tr>
                <td> <div class="container">
                        <p><span style="color: green">Already  have an account?</span>  <a href="index.php">sign in</a></p>
                    </div>
                </td>
            </tr>
        </table>
    </form>

</div>



</body>
</html>