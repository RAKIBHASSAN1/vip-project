
<?php require ('php_code.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Photo Gallery</title>
    <link rel="stylesheet" href="style.css" type="text/css">

</head>
<body>

<div class="banner">
    <div class="menu">
        <ul>
            <li> <a href="home.php" class="current" >Home</a></li>
            <li> <a href="upload.php">Upload</a></li>
            <li> <a href="contact.php">Contact Us</a></li>
            <li> <a href="adminlogin.php">Admin</a></li>
            <li> <a href="index.php">Logout</a></li>
        </ul>


    </div>

    <div class="heading">
        <h1>The best free stock photos</h1>
        <p>Capturing moments from today…Creating memories for a lifetime</p>
    </div>

</div>

<div class="image_section">
    <?php
    $result = mysqli_query($db, "SELECT * FROM images");

    while ($row = mysqli_fetch_array($result)) { ?>

        <img src=<?php echo 'uploaded_image/'.$row['image'] ;?> alt='' width="430px" height="280px" style="margin: 10px 0px 0px 13px ">

    <?php } ?>
</div>

</body>
</html>