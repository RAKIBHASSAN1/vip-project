<?php require ('php_code.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PhotoGallery/login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>



<div class="login_form">
    <form action="" method="post" id="design_form">
        <h1>Login</h1>
        <p>Please Sign in to visit our website</p>
        <table id="design_table">

            <tr>
                <td><input type="email" name="email" placeholder="Enter Email" required></td>
            </tr>

            <tr>
                <td><input type="password" name="password" placeholder="Enter Password" required></td>
            </tr>
            <tr>
                <td><input type="submit" name="login" value="Login" id="btn"></td>
            </tr>
            <tr>
                <td> <div class="container">
                        <p><span style="color: red">if not register?</span>  <a href="register.php">register Now</a></p>
                    </div>
                </td>
            </tr>

        </table>
    </form>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="msg">
            <?php
            echo $_SESSION['message'];
            unset($_SESSION['message']);
            ?>
        </div>
    <?php endif ?>
</div>



</body>
</html>