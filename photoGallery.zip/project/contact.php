<?php require ('php_code.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>photogallery/contact</title>
    <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>



<div class="design_menu">
    <div class="menu">
        <ul>
            <li> <a  href="home.php" >Home</a></li>
            <li> <a  href="upload.php">Upload</a></li>
            <li> <a class="current" href="contact.php">Contact Us</a></li>
            <li> <a href="adminlogin.php">Admin</a></li>
            <li> <a href="index.php">Logout</a></li>
        </ul>
    </div>
</div>

<div class="contact">
    <pre>
     <b style="color: deeppink">Address:</b>
       stamford university bangladesh, Dhaka-1217.
    <b style="color: deeppink"> Phone:</b>
      +8801774441359
     <b style="color: deeppink">Email:</b>
      photogallery@gmail.com
    </pre>
</div>

<div class="location">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3652.0806013254123!2d90.4062474144557!3d23.7445049949196!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b88bfd0133c5%3A0xfde0a96bf5fecf99!2sStamford+University+Bangladesh!5e0!3m2!1sen!2sbd!4v1555965016826!5m2!1sen!2sbd" width="100%" height="550"  frameborder="0" style="border:0" allowfullscreen></iframe>
</div>

<div class="footer">
    <p>connect us</p>
    <a href="https://www.facebook.com" target="_blank"> <img src="images/download.png" alt="" width="30px" style="margin-right: 5px" title="facebook"></a>
    <a href="https://www.instagram.com" target="_blank"><img src="images/download2.jpg" alt="" width="30px" style="margin-right: 5px" title="instagram"></a>
    <a href="https://www.twitter.com"  target="_blank"><img src="images/twitter.png" alt="" width="30px" title="twitter"></a>
    <p>All right reserved &copy; Photo Gallery 2019</p>
</div>

</body>
</html>