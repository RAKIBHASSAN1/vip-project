
<!DOCTYPE html>
<html>
	<head>
		<title>Programs Page</title>
		<link rel="stylesheet" type="text/css" href="styles/program.css">
       <!-- Latest compiled and minified CSS -->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

	</head>
	<body >
        <div class = "topbar">
            <div class= "menu">
                <div class="leftmenu">
                        <img src="images/logo.jpg"
                        alt="This is a logo"
                        width="200"
                        height="50"
                        title="User Logo">
                </div>
                <div class="rightmenu">
                    <ul>
                        <li id="fisrtlist"> <a class="nav-link" href="index.php"> HOME</a> </li>
                        <li><a class="nav-link" href="about.php">ABOUT</a></li>
                        <li><a  class="nav-link" href="program.php">PROGRAMS</a></li>
                        <li><a class="nav-link" href="contact.php">CONTACT US</a></li>
                        <li><a class="nav-link" href="login.php"> LOGIN</a></li>
                        <li><a class="nav-link" href="signup.php">SIGN UP</a></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class ="program-contain">
        
            <div class="container">
            <h2 style="
               text-align: center;
                color:black;
                padding-bottom:20px;

            ">
            
            Our Programes Here</h2>
                <div class="row">
                    <div class ="col-md-4">
                        <div class="card" style="width:350px">
                            <img class="card-img-top" src="images/busi.jpg" alt="Card image" style="height:200px;
                              width:190px">
                            <div class="card-body text-center ">
                            <h4 class="card-title ">Business</h4>
                            <p class="card-text">Business is the activity of making one's living or making money by producing or buying 
                                and selling products.Simply put, it is "any activity or enterprise entered into for profit. It does not 
                                mean it is a company, a corporation, partnership, or have any such </p>
                            <a href="bsmore.php" class="btn btn-primary stretched-link">More</a>
                            </div>
                        </div>
                    </div>
                    <div class ="col-md-4">
                        <div class="card " style="width:350px">
                            <img class="card-img-top pt-2" src="images/edu.jpg" alt="Card image" style="height:200px;
                              width:190px">
                            <div class="card-body text-center ">
                            <h4 class="card-title ">Education</h4>
                            <p class="card-text">Education is the process of facilitating learning, or the acquisition of knowledge,
                                 skills, values, beliefs, and habits. Educational methods include storytelling, discussion, teaching, training,
                                 and directed research.</p>
                            <a href="edumore.php" class="btn btn-primary stretched-link ">More</a>
                            </div>
                        </div>
                    </div>
                    <div class ="col-md-4">
                        <div class="card" style="width:350px">
                            <img class="card-img-top" src="images/care.jpg" alt="Card image" style="height:200px;
                              width:190px">
                            <div class="card-body text-center ">
                            <h4 class="card-title ">Health-Care</h4>
                            <p class="card-text">Health care or healthcare is the maintenance or improvement of health
                                via the prevention, diagnosis, and treatment of disease, illness, injury, and other physical
                                 and mental impairments in people .Health care is delivered by health professionals</p>
                            <a href="hcmore.php" class="btn btn-primary stretched-link">More</a>
                            </div>
                        </div>
                    </div>
                    <div class ="col-md-4 mt-3">
                        <div class="card" style="width:350px">
                            <img class="card-img-top" src="images/agricul.jpg" alt="Card image" style="height:200px;
                              width:190px">
                            <div class="card-body text-center ">
                            <h4 class="card-title ">Agriculture</h4>
                            <p class="card-text">Agriculture is the science and art of cultivating plants and livestock. Agriculture was the key development 
                                in the rise of sedentary human civilization, whereby farming of domesticated species created food surpluses that  
                             </p>
                            <a href="agmore.php" class="btn btn-primary stretched-link">More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</body>
</html>
		 
		
