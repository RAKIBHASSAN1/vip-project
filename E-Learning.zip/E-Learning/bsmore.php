<!DOCTYPE html>
<html>
	<head>
		<title>Programs Page</title>
		<link rel="stylesheet" type="text/css" href="styles/bsmore.css">
       <!-- Latest compiled and minified CSS -->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

	</head>
	<body >
        <div class = "topbar">
            <div class= "menu">
                <div class="leftmenu">
                        <img src="images/logo.jpg"
                        alt="This is a logo"
                        width="200"
                        height="50"
                        title="User Logo">
                </div>
                <div class="rightmenu">
                    <ul>
                        <li id="fisrtlist"> <a class="nav-link" href="index.php"> HOME</a> </li>
                        <li><a class="nav-link" href="about.php">ABOUT</a></li>
                        <li><a  class="nav-link" href="program.php">PROGRAMS</a></li>
                        <li><a class="nav-link" href="contact.php">CONTACT US</a></li>
                        <li><a class="nav-link" href="login.php"> LOGIN</a></li>
                        <li><a class="nav-link" href="signup.php">SIGN UP</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="bstext">
            <h4>Business</h4>
            <p class="card-text">
                Business is the activity of making one's living or making money by producing or buying and selling products.</p>
                <p>Simply put, it is "any activity or enterprise entered into for profit. It does not mean it is a company,</p>
                 <p>a corporation, partnership, or have any such formal organization, but it can range from a street peddler to
                 General Motors.</p>

                <p>Having a business name does not separate the business entity from the owner, which means that the owner of.</p>
               <p> the business is responsible and liable for debts incurred by the business. If the business acquires debts, the</p>
                <p>creditors can go after the owner's personal possessions.A business structure does not allow for corporate tax </p>
                <p>rates. The proprietor is personally taxed on all income from the business.</p>

                 <p>The term is also often used colloquially (but not by lawyers or by public officials) to refer to a company.</p>
                <p> A company, on the other hand, is a separate legal entity and provides for limited liability, as well as corporate</p>
                 <p>tax rates. A company structure is more complicated and expensive to set up, but offers more protection and benefits 
                 for the owner.</p>
			
        </div>
        <div class ="col-md-6">
                        <div class="card " style="width:350px">
                            <div class="card-body text-center ">
                            <h4 class="card-title ">Content</h5>
                            <h5>	<u>Activities:</u></h6>
                                <ul>
                                  
                                  <li>Accounting</li>
                                  <li> Finance</li>
                                  <li> Manufacturing</li>
                                  <li>Marketing</li>
                                  <li> Safety</li>
                                  <li>Sales </li>  

                                </ul>
                            </div>
                        </div>
                    </div>
</body>
</html>
      