<?php	
	session_start();
	$mysqli = new mysqli('localhost', 'root', '', 'marzia');
	
	if($mysqli === false){
		die("ERROR: Could not connect. " . $mysqli->connect_error);
	}
	
	$username = $password = "";
	$username_err = $password_err = "";
	// Processing form data when form is submitted
	if($_SERVER["REQUEST_METHOD"] == "POST"){
	
		// Check if username is empty
		if(empty(trim($_POST["username"]))){
			$username_err = "Please enter username.";
		} else{
			$username = trim($_POST["username"]);
		}
		// Check if password is empty
		if(empty(trim($_POST["password"]))){
			$password_err = "Please enter your password.";
		} else{
			$password = trim($_POST["password"]);
		}
		if(empty($username_err) && empty($password_err)){
		$sql="SELECT * FROM register WHERE username='$username' AND passwordd='$password' LIMIT 1";
			if($result = $mysqli->query($sql))
			{
				if($result->num_rows > 0)
				{
					echo "you have successfully login";
					$_SESSION[user]=$username;
					header("location: index.php");
				}
				else
				{
					echo "Username or Password is wrong!";
					header("location: login.php");
				}
			}
		}
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Login Page</title>
		<link rel="stylesheet" type="text/css" href="styles/style.css">

	</head>
	<body class="login">
		<img src="images/aa.png" 
		class="avatar"
		alt="This is a logo"
		title="User Logo">
		<div class="menu">
			<div class="leftmenu">
					<img src="images/logo.jpg"
					alt="This is a logo"
					width="200"
					height="50"
					title="User Logo">
			</div>
			<div class="rightmenu">
				<ul>
					<li id="fisrtlist"> <a class="nav-link" href="index.php"> HOME</a> </li>
					<li><a class="nav-link" href="about">ABOUT</a></li>
					<li><a  class="nav-link" href="program.php">PROGRAMS</a></li>
					<li><a class="nav-link" href="contact.php">CONTACT US</a></li>
					<li><a class="nav-link" href="#"> LOGIN</a></li>
					<li><a class="nav-link" href="signup.php">SIGN UP</a></li>
				</ul>
			</div>
		</div>

		<div class="header">
			<h2><a href="#">Login</a></h2>
		</div> 
		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
			<div class="input-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
				<label>Username</label>
				<input type="text" name="username" placeholder="Enter Username">
				<span class="help-block"><?php echo $username_err; ?></span>
			</div>
			<div class="input-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
				<label>Password</label>
				<input type="password" name="password" placeholder="Enter Password">
				<span class="help-block"><?php echo $password_err; ?></span>
			</div>
			<div class="input-group">
				<button type="submit" name="login" class="btn">Login</button>
			</div>
			
			<p class="logp" >
				Not yet a member? <a class="log" href="signup.php">Sign up</a>
			</p>
			
		</form>
	</body>
</html>