<?php
$mysqli = new mysqli('localhost', 'root', '', 'marzia');
 
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}

$username =$email = $password = $confirm_password = "";
$username_err = $email_err = $password_err = $confirm_password_err = "";
 
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } else{
        $sql = "SELECT username FROM register WHERE username = ?";
        
        if($stmt = $mysqli->prepare($sql)){
            $stmt->bind_param("s", $param_username);
            
            $param_username = trim($_POST["username"]);
            
            if($stmt->execute()){
                $stmt->store_result();
                
                if($stmt->num_rows == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        $stmt->close();
	}
	
	if(empty(trim($_POST["email"]))){
        $email_err = "Please enter a email.";
    } else{
        $sql = "SELECT email FROM register WHERE email = ?";
        
        if($stmt = $mysqli->prepare($sql)){
            $stmt->bind_param("s", $param_email);
            
            $param_email = trim($_POST["email"]);
            
            if($stmt->execute()){
                $stmt->store_result();
                
                if($stmt->num_rows == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $email = trim($_POST["email"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        $stmt->close();
    }

    
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
    if(empty($username_err) && empty($email_err) && empty($password_err) && empty($confirm_password_err)){
        
        $sql = "INSERT INTO register (username, email, passwordd) VALUES (?, ?, ?)";
         
        if($stmt = $mysqli->prepare($sql)){
            $stmt->bind_param("sss", $param_username,$param_email, $param_password);
            
            $param_username = $username;
			$param_email=$email;
            $param_password = $password; // Creates a password hash
            
            if($stmt->execute()){
                header("location: login.php");
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        $stmt->close();
    }
    
    $mysqli->close();
}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Sign Up Page</title>
		<link rel="stylesheet" type="text/css" href="styles/style.css">
	</head>
	<body>
		<img src="images/aa.png" 
			class="avatar"
			alt="This is a logo"
			title="User Logo">
		<div class="menu">
			<div class="leftmenu">
				<img src="images/logo.jpg"
					alt="This is a logo"
					width="200"
					height="50"
					title="Project Logo">
			</div>
			<div class="rightmenu">
				<ul>
					<li id="fisrtlist"> <a class="nav-link" href="index.php"> HOME</a> </li>
					<li><a class="nav-link" href="about.php">ABOUT</a></li>
					<li><a  class="nav-link" href="program.php">PROGRAMS</a></li>
					<li><a class="nav-link" href="contact.php">CONTACT US</a></li>
					<li><a class="nav-link" href="login.php"> LOGIN</a></li>
					<li><a class="nav-link" href="#">SIGN UP</a></li>
				</ul>
					</div>
				</div>
		<div class="header">
			<h2><a href="#">Sign Up</a></h2>
		</div> 

		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
			<div class="input-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
				<label><b>Username</b></label>
				<input type="text" name="username" placeholder="Enter Username">
				<span class="help-block"><?php echo $username_err; ?></span>
			</div>
			<div class="input-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
				<label><b>Email</b></label>
				<input type="text" name="email" placeholder="Enter Email Address">
				<span class="help-block"><?php echo $email_err; ?></span>
			</div>
			<div class="input-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
				<label><b>Password</b></label>
				<input type="password" name="password" placeholder="Enter Password">
				<span class="help-block"><?php echo $password_err; ?></span>
			</div>
			<div class="input-group <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
				<label><b>Confirm Password</b></label>
				<input type="password" name="confirm_password" placeholder="Retype New Password">
				<span class="help-block"><?php echo $confirm_password_err; ?></span>
			</div>
			<div class="input-group">
				<button type="submit" name="register" class="btn">Sign Up</button>
			</div>
			<p class="signp">
				Already a member? <a class="sign" href="login.php">Sign in</a>
			</p>	
		</form>
	</body>
</html>