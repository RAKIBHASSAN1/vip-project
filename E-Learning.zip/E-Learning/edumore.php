<!DOCTYPE html>
<html>
	<head>
		<title>Programs Page</title>
		<link rel="stylesheet" type="text/css" href="styles/bsmore.css">
       <!-- Latest compiled and minified CSS -->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

	</head>
	<body >
        <div class = "topbar">
            <div class= "menu">
                <div class="leftmenu">
                        <img src="images/logo.jpg"
                        alt="This is a logo"
                        width="200"
                        height="50"
                        title="User Logo">
                </div>
                <div class="rightmenu">
                    <ul>
                        <li id="fisrtlist"> <a class="nav-link" href="index.php"> HOME</a> </li>
                        <li><a class="nav-link" href="about.php">ABOUT</a></li>
                        <li><a  class="nav-link" href="program.php">PROGRAMS</a></li>
                        <li><a class="nav-link" href="contact.php">CONTACT US</a></li>
                        <li><a class="nav-link" href="login.php"> LOGIN</a></li>
                        <li><a class="nav-link" href="signup.php">SIGN UP</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="bstext">
            <h4>Education</h4>
            <p>Education frequently takes place under the guidance of educators and also learners may also educate themselves. </p>
            <p>Education can take place in formal or informal settings and any experience that has a formative effect on the </p>
            <p> way one thinks, feels, or acts may be considered educational. The methodology of teaching is called pedagogy. </p>
            <p>Formal education is commonly divided formally into such stages as preschool or kindergarten, primary school, </p>
            <p>secondary school and then college, university, or apprenticeship.A right to education has been recognized </p>
            <p>by some governments and the United Nations. In most regions, education is compulsory up to a certain age. </p>
        </div>
        <div class ="col-md-6">
                        <div class="card " style="width:350px">
                            <div class="card-body text-center ">
                            <h4 class="card-title ">Content</h4>
                            <h5>	<u>Formal education:</u></h5>
                                <ul>
                                  
                                  <li>Preschool</li>
                                  <li> primary</li>
                                  <li> Secondary</li>
                                  <li> Tertiary (higher)</li>
                                  <li> Vocational</li>
                                  <li>Special </li>  

                                </ul>
                            </div>
                        </div>
                    </div>
</body>
</html>
      