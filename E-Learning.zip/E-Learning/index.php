<!DOCTYPE html>
<html>
	<head>
		<title>E-Learning</title>
		<link rel="stylesheet" type="text/css" href="styles/style.css">
		<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
		<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CPT+Serif:400,700,400italic' 		rel='stylesheet'>
		<link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans" rel="stylesheet">
	</head>
	<body>
		<div class="bgimage">
			<div class="menu">
				<div class="leftmenu">
						<img src="images/logo.jpg"
						alt="This is a logo"
						width="200"
						height="50"
						title="Project Logo">
				</div>
			<div class="rightmenu">
				<ul>
					<li id="fisrtlist"> <a class="nav-link" href="#"> HOME</a> </li>
					<li><a class="nav-link" href="about.php">ABOUT</a></li>
					<li><a  class="nav-link" href="program.php">PROGRAMS</a></li>
					<li><a class="nav-link" href="contact.php">CONTACT US</a></li>
					<li><a class="nav-link" href="login.php"> LOGIN</a></li>
					<li><a class="nav-link" href="signup.php">SIGN UP</a></li>
				</ul>
			</div>
			</div>
		</div>
		<div class="text">
			<h4>What is e-Learning?</h4>
			<p>Understanding eLearning is simple. eLearning is learning utilizing electronic</p>
			<p>technologies to access educational curriculum outside of a traditional classroom.</p> 
			<p>In most cases, it refers to a course, program or degree delivered completely online.</p>
			<p>There are many terms used to describe learning that is delivered online,</p>
			<p>via the internet, ranging from Distance Education, to computerized electronic</p> 
			<p>learning,online learning, internet learning and many others. We define eLearning</p>
			<p>as courses that are specifically delivered via the internet to somewhere other</p>
			<p>than the classroom where the professor is teaching.</p>
			<button id= "buttonone" > like share </button> 
		</div>
		<div class="footer_bg">
			<div id="wrap">
				<footer>
					<div id="footer_wrap">
						<div id="footer_left">
							<h2> Catagories </h2>
							<ul>
								<li><a href=""> Html </a></li>
								<li><a href=""> Css </a></li>
								<li><a href=""> Javascript </a></li>
								<li><a href=""> Php </a></li>
							</ul>
						</div>
						<div id="footer_middle">
							<h2> Blog Post </h2>
							<ul>
								<li><a href="#"> Blog post description </a></li>
								<li><a href="#"> Blog post description </a></li>
								<li><a href="#"> Blog post description </a></li>
								<li><a href="#"> Blog post description </a></li>
							</ul>
						</div>
						<div id="footer_right">
							<h2> FLOW US </h2>
							<ul>
								<li>
									<a href="#"><i class="fa fa-facebook" style="margin-right:10px;"></i>Facebook</a>
									<a href="#"><i class="fa fa-twitter" style="margin-right:10px;"></i>Twiter</a>
									<a href="#"><i class="fa fa-google" style="margin-right:10px;"></i>Google</a>
									<a href="#"><i class="fa fa-youtube" style="margin-right:10px;"></i>Youtube</a>
								</li>	
							</ul>
						</div>
					</div>	
				</footer>
			</div>
		</div>	
	</body>
</html>