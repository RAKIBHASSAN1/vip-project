<!DOCTYPE html>
<html>
	<head>
		<title>Programs Page</title>
		<link rel="stylesheet" type="text/css" href="styles/bsmore.css">
       <!-- Latest compiled and minified CSS -->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

	</head>
	<body >
        <div class = "topbar">
            <div class= "menu">
                <div class="leftmenu">
                        <img src="images/logo.jpg"
                        alt="This is a logo"
                        width="200"
                        height="50"
                        title="User Logo">
                </div>
                <div class="rightmenu">
                    <ul>
                        <li id="fisrtlist"> <a class="nav-link" href="index.php"> HOME</a> </li>
                        <li><a class="nav-link" href="about.php">ABOUT</a></li>
                        <li><a  class="nav-link" href="program.php">PROGRAMS</a></li>
                        <li><a class="nav-link" href="contact.php">CONTACT US</a></li>
                        <li><a class="nav-link" href="login.php"> LOGIN</a></li>
                        <li><a class="nav-link" href="signup.php">SIGN UP</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="bstext">
            <h4>Agriculture</h4>
           <p> enabled people to live in cities. The history of agriculture began thousands of years ago. After gathering wild grains  </p> 
           <p>  beginning at least 105,000 years ago, nascent farmers began to plant them around 11,500 years ago. Pigs, sheep and cattle </p> 
           <p> were domesticated over 10,000 years ago.Plants were independently cultivated in at least 11 regions of the world. Industrial </p> 
           <p>  agriculture based on large-scal e monoculture in the twentieth century came to dominate agricultural output, though about 2 </p> 
           <p> billion people still depended on subsistence agriculture into the twenty-first. <p> 
           <p> Modern agronomy, plant breeding, agrochemicals such as pesticides and fertilizers, and technological developments have sharply </p> 
           <p> increased yields, while causing widespread ecological and environmental damage. Selective breeding and modern practices in </p> 
           <p> animal husbandry have similarly increased the output of meat, but have raised concerns about animal welfare and environmental </p> 
           <p> damage. Environmental issues include contributions to global warming, depletion of aquifers, deforestation, antibiotic resistance, </p> 
           <p> and growth hormones in ndustrial meat production. Genetically modified organisms are widely used, although some are banned in certain  </p> 
           <p> countries.The major agricultural products can be broadly grouped into foods, fibers, fuels and raw materials (such as rubber). Food classes </p> 
           <p> include cereals (grains), vegetables, fruits, oils, meat, milk, fungi and eggs. Over one-third of the world's workers are employed </p> 
           <p>  in agriculture, second only to the service sector, although the number of agricultural workers in developed countries has decreased </p> 
           <p> significantly over the centuries. <p> 
           
        </div>
        <div class ="col-md-6">
                        <div class="card " style="width:350px">
                            <div class="card-body text-center ">
                            <h4 class="card-title ">Content</h4>
                            <h5>	<u>Production:</u></h5>
                                <ul>
                                  
                                  <li>Crop cultivation systems</li>
                                  <li> Livestock production systems</li>
                                  <li>Production  practices</li>
                                  

                                </ul>
                            </div>
                        </div>
                    </div>
</body>
</html>
      