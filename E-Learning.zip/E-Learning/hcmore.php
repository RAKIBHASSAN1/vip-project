<!DOCTYPE html>
<html>
	<head>
		<title>Programs Page</title>
		<link rel="stylesheet" type="text/css" href="styles/bsmore.css">
       <!-- Latest compiled and minified CSS -->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

	</head>
	<body >
        <div class = "topbar">
            <div class= "menu">
                <div class="leftmenu">
                        <img src="images/logo.jpg"
                        alt="This is a logo"
                        width="200"
                        height="50"
                        title="User Logo">
                </div>
                <div class="rightmenu">
                    <ul>
                        <li id="fisrtlist"> <a class="nav-link" href="index.php"> HOME</a> </li>
                        <li><a class="nav-link" href="about.php">ABOUT</a></li>
                        <li><a  class="nav-link" href="program.php">PROGRAMS</a></li>
                        <li><a class="nav-link" href="contact.php">CONTACT US</a></li>
                        <li><a class="nav-link" href="login.php"> LOGIN</a></li>
                        <li><a class="nav-link" href="signup.php">SIGN UP</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="bstext">
            <h4>Health-Care</h4>
            <p>Health care or healthcare is the maintenance or improvement of health via the prevention, diagnosis, and treatment </p>
            <p>of disease, illness, injury, and other physical and mental impairments in people. Health care is delivered by health  </p>
            <p>professionals (providers or practitioners) in allied health fields. Physicians and physician associates are a part of these  </p>
            <p>health professionals. Dentistry, midwifery, nursing, medicine, optometry, audiology, pharmacy, psychology, occupational therapy, </p>
            <p> physical therapy and other health professions are all part of health care. It includes work done in providing primary care, </p>
            <p>secondary care,and tertiary care, as well as in public health.Access to health care may vary across countries, communities,  </p>
            <p>and individuals, largely influenced by social and economic conditions as well as health policies. Health care systems are </p>
            <p>organizations established to meet the health needs of targeted populations. According to the World Health Organization (WHO), </p>
            <p> a well-functioning health care system requires a financing mechanism, a well-trained and adequately  paid workforce, reliable </p>
            <p>information on which to base decisions and policies, and well maintained health facilities to deliver quality medicines and </p>
            <p> technologies.An efficient health care system can contribute to a significant part of a country's economy, development and </p>
            <p>industrialization. Health care is conventionally regarded as an important determinant in promoting the general physical </p>
            <p>and mental health and well-being of people around the world. An example of this was the worldwide eradication of smallpox  </p>
            <p> in 1980, declared by the WHO as the first disease in human history to be completely eliminated by deliberate health care interventions. </p>


   
        </div>
        <div class ="col-md-6">
                        <div class="card " style="width:350px">
                            <div class="card-body text-center ">
                            <h4 class="card-title ">Content</h4>
                            <h5>	<u>Related Sectors:</u></h5>
                                <ul>
                                  
                                  <li>Health System</li>
                                  <li> Health Care Industry</li>
                                  <li> Health Care Research</li>
                                  <li> Health Care financing</li>
                                  <li>Health Information Technology</li>
                                

                                </ul>
                            </div>
                        </div>
                    </div>
</body>
</html>
      