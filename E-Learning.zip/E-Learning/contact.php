
<!DOCTYPE html>
<html>
	<head>
		<title>Contact Page</title>
		<link rel="stylesheet" type="text/css" href="styles/contact.css">
       <!-- Latest compiled and minified CSS -->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	</head>
	<body >
        <div class = "topbar">
            <div class= "menu">
                <div class="leftmenu">
                        <img src="images/logo.jpg"
                        alt="This is a logo"
                        width="200"
                        height="50"
                        title="User Logo">
                </div>
                <div class="rightmenu">
                    <ul>
                        <li id="fisrtlist"> <a class="nav-link" href="index.php"> HOME</a> </li>
                        <li><a class="nav-link" href="about.php">ABOUT</a></li>
                        <li><a  class="nav-link" href="program.php">PROGRAMS</a></li>
                        <li><a class="nav-link" href="#">CONTACT US</a></li>
                        <li><a class="nav-link" href="login.php"> LOGIN</a></li>
                        <li><a class="nav-link" href="signup.php">SIGN UP</a></li>
                    </ul>
                </div>
            </div>
        </div>
      <div class = "contact">
          <div class="container mt-5">
              <div class="row">
                  <div class="contact-us text-center">
                      <h2>Contact Us </h2>
                      <a href="#">Overview</a>
                      <a href="#">Meet Our Team</a>
                      <a href="#">Join Our Team</a>
                      <a href="#">Our Story</a>
                      <a href="#">We Care</a>
                      <a href="#">Contact Us</a>
                      <p>Call us, email us, or send in our quick and easy form. The choice is yours. We'll help you find a great team  E-learning in no time! </p>
                  </div>
              </div>
          </div>
      </div>
      <div class ="contact-info">
          <div class="container">
              <div class="row">
                  <div class="col-md-6">
                      <div class="contact-info-text mt-4">
                          <p>Give us a call at <strong> 01883-471597 </strong>or email us at </p>
                          <p><strong>Elearning@gmail.com </strong>Our dedicated team of Employee Engagement Consultants is available to talk with you Monday to Friday from 9:00AM - 5:00PM your time, regardless of which time zone you're located in.</p>
                          <p >Please provide us with as much information as possible to help us prepare better for our conversation with you. Here are some things to include:</p>
                          <p class="pl-4 bold" >>Your name, role, company, and where you're located </p>
                          <p class="pl-4">>The best number to reach you at today</p>
                          <p class="pl-4">>What event you're most interested in, and why</p>
                          <p class="pl-4">>What date your event is scheduled for, and where </p>
                          <p>Looking to contact a specific team member? Meet Our Team has contact details for each staff member</p>
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="google-map mt-4">
                          <img src="images/g-map.jpg" alt="map">
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <footer>
            <div class ="contact-footer">
                <div class ="container ">
                    <div class="row">
                        <div class= "col-md-12 ftr">
                        <p>Home | Aboutus |  K-12 E-Learning | College E-Learning | Career E-Learning | Facilitating E-Learning   </p>
                        <p>© Copyright 2019 E-Learning By <strong>Marzia & Eva</strong> </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </body>
</html>