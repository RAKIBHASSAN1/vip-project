
<!DOCTYPE html>
<html>
	<head>
		<title>About Page</title>
		<link rel="stylesheet" type="text/css" href="styles/about.css">
       <!-- Latest compiled and minified CSS -->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

	</head>
	<body >
        <div class = "topbar">
            <div class= "menu">
                <div class="leftmenu">
                        <img src="images/logo.jpg"
                        alt="This is a logo"
                        width="200"
                        height="50"
                        title="User Logo">
                </div>
                <div class="rightmenu">
                    <ul>
                        <li id="fisrtlist"> <a class="nav-link" href="index.php"> HOME</a> </li>
                        <li><a class="nav-link" href="#">ABOUT</a></li>
                        <li><a  class="nav-link" href="program.php">PROGRAMS</a></li>
                        <li><a class="nav-link" href="contact.php">CONTACT US</a></li>
                        <li><a class="nav-link" href="login.php"> LOGIN</a></li>
                        <li><a class="nav-link" href="signup.php">SIGN UP</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="about-elearn">
            <div class= "container">
            <h2>About E-Learning</h2>
                <div class="row">
                    <div class="col-md-3">
                
                        <img class = "img-1" src="images/log.jpg" alt="marzia"style="height:600;width:500">
                    </div>
        
                    <div class ="col-md-6 bdr">
                        <h3>What is eLearning?</h3>
                        <p>Understanding eLearning is simple. eLearning is learning utilizing electronic technologies to access educational curriculum outside of a traditional classroom.  In most cases, it refers to a course, program or degree delivered completely online.</p>
                        <p>There are many terms used to describe learning that is delivered online, via the internet, ranging from Distance Education, to computerized electronic learning, online learning, internet learning and many others. We define eLearning as courses that are specifically delivered via the internet to somewhere other than the classroom where the professor is teaching. It is not a course delivered via a DVD or CD-ROM, video tape or over a television channel. It is interactive in that you can also communicate with your teachers, professors or other students in your class. Sometimes it is delivered live, where you can “electronically” raise your hand and interact in real time and sometimes it is a lecture that has been prerecorded. There is always a teacher or professor interacting /communicating with you and grading your participation, your assignments and your tests. eLearning has been proven to be a successful method of training and education is becoming a way of life for many citizens in North Carolina.</p>
                        <p>To find out more about eLearning, simply select from the links on the left menu.</p>

                    </div>
                </div>
            </div>
        </div>
        <footer>
            <div class ="about-footer">
                <div class ="container ">
                    <div class="row">
                        <div class= "col-md-12 ftr">
                        <p>Home | Aboutus |  K-12 E-Learning | College E-Learning | Career E-Learning | Facilitating E-Learning   </p>
                        <p>© Copyright 2019 E-Learning By <strong>Marzia & Eva</strong> </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </body>
</html>