<?php
 session_start();
 ?>
 <!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="Styles/home.css" rel="stylesheet" type="text/css">
        <link href="Styles/nav.css" rel="stylesheet" type="text/css">
        <link rel="shortcut icon" href="Pictures/gg.jpg" type="image/png">
    </head>
    <body>
        <div>
            <ul class="nav">
                <li><a href="PHP/logout.php">Logout</a></li>
                <li><a href="notification.php">Notification</a></li>
                <li><a href="post.php">Post a work</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="home.php">Home</a></li>
                <title>Notification</title>
            </ul>
        </div>
        <?php 
        $mysql = new mysqli('localhost', 'root', '', 'gg');
        $email = $_SESSION['email'];
        $query ="SELECT * FROM notify WHERE email='$email'";
        
        if($results = $mysql->query($query)){
            while ($row = $results->fetch_array()){?>
                <div class='post'>
                <h2 style='margin:10px 0'><?php echo $row['name']?> accepted your offer.</h2>
                <p style='margin:5px 0'>We have given him/her your email addres. Sooner or letter he/she will be in touch with you</p>
                <p style='margin:5px 0'>NB : If you are in a deal you can delete your post</P>
                <a href="PHP/clear.php?cle=<?php echo $row['id']; ?>" style="text-decoration: none;padding: 5px 5px;background: #f45942">Clear this notification</a>
    
                </div>
            <?php }?>

        <?php } ?>
        
    </body>
</html>