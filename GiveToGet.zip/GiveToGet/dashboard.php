<?php
 session_start();
 ?>
 <!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="Styles/home.css" rel="stylesheet" type="text/css">
        <link href="Styles/nav.css" rel="stylesheet" type="text/css">
        <link rel="shortcut icon" href="Pictures/gg.jpg" type="image/png">
        <title>Dashboard</title>
    </head>
    <body>
        <div>
            <ul class="nav">
                <li><a href="PHP/logout.php">Logout</a></li>
                <li><a hfre="notification.php">Notification</a></li>
                <li><a href="post.php">Post a work</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="home.php">Home</a></li>
            </ul>
        </div>
        <?php 
        $mysql = new mysqli('localhost', 'root', '', 'gg');
        $name = $_SESSION['name'];
        $query ="SELECT * FROM posts WHERE name='$name'";
        
        if($results = $mysql->query($query)){
            while ($row = $results->fetch_array()){?>
                <div class='post'>
                <h2 style='margin:10px 0'>You offered <?php echo $row['give']?> for <?php echo $row['gett'] ?></h2>
                <p style='margin:5px 0'><?php echo $row['status'] ?></p>
                <p style='margin:5px 0'>On <?php echo $row['time']?></P>
                <a href="PHP/delete.php?del=<?php echo $row['id']; ?>" style="text-decoration: none;padding: 5px 5px;background: #f45942">Delete this post</a>
    
                </div>
            <?php }?>

        <?php } ?>
        
        
        
        
    </body>
</html>