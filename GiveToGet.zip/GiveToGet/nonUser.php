<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Give to Get</title>
        <link href="Styles/styles.css" rel="stylesheet" type="text/css">
        <link href="Styles/nav.css" rel="stylesheet" type="text/css">
        <link rel="shortcut icon" href="Pictures/gg.jpg" type="image/png">
        <link href="Styles/from.css" rel="stylesheet" type="text/css">
        
        <style>
            html { 
                background-color: rgb(29, 158, 209);
            }
            
        </style>
    </head>
    <body >
        
        <div class="navigation">
             <ul class="login">
                <li style="float: left"><p class="header">Give to Get</p></li>
                <li><a href="signup.php">Signup</a></li>
                <li><a href="login.php">Login</a></li>
                
                
            </ul>
        </div>
        
        <div class="home_text">
            <p>Need work done?</p>
            <p class="para" style="margin-top: 20px">Its very easy here to get your work done with money or without money.
                If you need to get some word is done then pay someone to get done your work but 
                if you do not have any money then complete someones work and in return he/she will
                complete your work.
                <p style="margin-top: 40px">Now start working...</p>
                
        </div>
              
        
    </body>
</html>