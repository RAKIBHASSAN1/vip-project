<?php
 session_start();


 if (isset($_SESSION['email']) && isset($_SESSION['pass'])) {

   header("Location:home.php");
   exit; 
 

 } else {
   
   header("Location:nonUser.php"); 
   exit;
   
 }
 ?>