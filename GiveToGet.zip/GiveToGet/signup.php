<?php include('PHP/signupController.php')?>
<!DOCTYPE html>
<html>
<head>
    <title>GG : Signup</title>
    <link rel="shortcut icon" href="Pictures/gg.jpg" type="image/png">
    <link rel="stylesheet" type="text/css" href="Styles/form.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<form id="form" method="post" action="PHP/signupController.php">
                
                <div>
                
                    <div style="margin:10px 0">
                        <div class="input-group">
                            <label>Name : </label>
                            <input type="text" name="name" placeholder="Enter name" required>
                        </div>  
                    </div>
                    
                    <div style="margin:10px 0">
                        <div class="input-group">
                            <label>Email : </label>
                            <input type="email" id="email" name="email" placeholder="Enter email" required>
                        </div>
                    </div>
                    <div style="margin:10px 0">
                        <div class="input-group">
                            <label>Password : </label>
                            <input type="password" id="pass" name="pass" placeholder="Enter password" required>
                        </div>
                    </div>
                    <div style="margin:10px 0">
                        <div class="input-group">
                            <label>Re-enter Password : </label>
                            <input type="password" id="pass" name="pass1" placeholder="Re-enter password" required>
                        </div>
                    </div>
                    
                    <div class="input-group">
                        
                        <button type="submit" class="btn" name="submit" >Sign Up</button>
                        
                    </div>
                   
                </form>
</body>
</html>