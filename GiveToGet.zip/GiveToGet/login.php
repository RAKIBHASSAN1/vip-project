<?php include('PHP/loginController.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>GG : Login</title>
    <link rel="shortcut icon" href="Pictures/gg.jpg" type="image/png">
    <link rel="stylesheet" type="text/css" href="Styles/form.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<form method="post" action="PHP/loginController.php" >
		<div class="input-group">
			<label>Email : </label>
			<input type="email" name="email" required>
		</div>
		<div class="input-group">
			<label>Password : </label>
			<input type="password" name="password" required>
		</div>
		<div class="input-group">
			<button class="btn" type="submit" name="submit" >Login</button>
		</div>
	</form>
</body>
</html>