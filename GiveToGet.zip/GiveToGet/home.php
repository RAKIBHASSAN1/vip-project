<?php session_start(); ?>
<!DOCTYPE html>
<html>
    <head>
        <link href="Styles/home.css" rel="stylesheet" type="text/css">
        <link href="Styles/nav.css" rel="stylesheet" type="text/css">
        <link rel="shortcut icon" href="Pictures/gg.jpg" type="image/png">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Home</title>
    </head>
    <body>
        <div>
            <ul class="nav">
                <li><a href="PHP/logout.php">Logout</a></li>
                <li><a href="notification.php">Notification</a></li>
                <li><a href="post.php">Post a work</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="home.php">Home</a></li>
            </ul>
        </div>
    <?php 
    $connection = new mysqli('localhost', 'root', '', 'gg');
    $query = "SELECT * FROM posts";
    $results = $connection->query($query);
    while ($row = $results->fetch_array()){?>
        
       <?php $name = $row['name'];?>
       <?php $myName = $_SESSION['name'];?>
        
        <div class='post'>
        <h2 style='margin:10px 0'><?php echo $name ?> offers <?php echo $row['give']?> for <?php echo $row['gett']?></h2>
        <p style='margin:5px 0'><?php echo $row['status']?></p>
        <p style='margin:5px 0'>Posted On :<?php echo $row['time']?></P>
        <a href="PHP/accept.php?acp=<?php echo $row['id']; ?>" style="text-decoration: none;padding: 5px 5px;background: #37b739">Accept this offer</a>
        </div>
        <?php }?>

        
    </body>
</html>