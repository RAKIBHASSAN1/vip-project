<?php include('PHP/postController.php')?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="Styles/post.css" rel="stylesheet" type="text/css">
        <link href="Styles/nav.css" rel="stylesheet" type="text/css">
        <link rel="shortcut icon" href="Pictures/gg.jpg" type="image/png">
        <title>Post Work</title>
        <style>
            body{
                background-image: url("Pictures/formback.jpg");
                background-color: #cccccc;
                height: 100%;
                background-position: center;
                background-repeat: no-repeat;
                background-size: cover;
                position: relative;
                background-attachment: fixed;
                background-position: center top; 
                opacity: 0.7;
                filter: alpha(opacity=50);
                            }
        </style>
    </head>
    <body>
        <div>
            <ul class="nav">
                <li><a href="PHP/logout.php">Logout</a></li>
                <li><a href="notification.php">Notification</a></li>
                <li><a href="post.php">Post a work</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="home.php">Home</a></li>
            </ul>
        </div>
        <div><h1 class="header">Put some details of your work...</h1></div>
        <div>
            <form id="form" method="POST" action="PHP/postController.php" >
                
                    <div>
                        <label for="give">What you want to do? :</label>
                        <select id="give" name="give">
                            <option>Java</option>
                            <option>PHP</option>
                            <option>Python</option>
                            <option>Full web development</option>
                            <option>Photoshop</option>
                            <option>Article writing</option>
                            <option>Money</option>
                        </select>   
                    </div>
                    <div>
                        <label for="gets">In exchange what you want? :</label>
                        <select id="get" name="get">
                            <option>Java</option>
                            <option>PHP</option>
                            <option>Python</option>
                            <option>Full web development</option>
                            <option>Photoshop</option>
                            <option>Article writing</option>
                            <option>Money</option>
                        </select>   
                    </div>
                    <div>
                        <label for="note" style="margin-bottom: 50px">Short description of your work :</label>
                        <textarea rows="4" cols="50" placeholder="Write something" name="note" id="note"></textarea>
                    </div>
                    <button name="post">Post</button>
                            
                           
                           
            </form>
        </div>
        
    </body>
</html>