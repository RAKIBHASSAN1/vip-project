<?php
    session_start();
    $mysql = new mysqli('localhost', 'root', '', 'gg');
    $email = "";
    $pass = "";
    if(isset($_POST['submit'])){
        $email = $_POST['email'];
        $pass = $_POST['password'];
        $query = "SELECT * FROM userinfo WHERE email='$email' AND pass='$pass'";
        $result = $mysql->query($query);
        if($result){
            $_SESSION['email']=$email;
            $_SESSION['pass']=$pass;
            $row = $result -> fetch_array();
            $name = $row['name'];
            $_SESSION['name'] = $name;
            header('location:../home.php');  
        }else{
           
           // header('location:../login.php');
           echo "Login Failed for email :".$email;
           
        }
    }

    
?>
