<?php

$mysql = new mysqli('localhost', 'root', '', 'gg');

if (isset($_GET['del'])) {
	$id = $_GET['del'];
	$mysql->query("DELETE FROM posts WHERE id=$id");
	header('location:../dashboard.php');
}
?>