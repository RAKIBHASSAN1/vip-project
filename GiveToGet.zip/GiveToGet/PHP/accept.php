<?php
session_start();
$myName = $_SESSION['name'];
$mysql = new mysqli('localhost', 'root', '', 'gg');


if (isset($_GET['acp'])) {
    $id = $_GET['acp'];
    $email = " ";
    $owner = " ";
   
    
    $results = $mysql->query("SELECT * FROM posts WHERE id='$id'");
    while($row = $results->fetch_array()){
        $email = $row['email'];
        $owner = $row['name'];
    }
       
    $res = $mysql->query("INSERT INTO notify(name,email) VALUES('$myName','$email')");
    if($res){
        $message = "Email of ".$owner." is ".$email." . Contact with the person";
        echo $message;
          }

    
}

?>