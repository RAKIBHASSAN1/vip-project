<?php 
	
	$connection = new mysqli('localhost', 'root', '', 'gg');
	$name = "";
    $email = "";
    $pass ="";

	if (isset($_POST['submit'])) {
		$name = $_POST['name'];
        $email = $_POST['email'];
        $pass1 = $_POST['pass'];
        $pass2 = $_POST['pass1'];
        
        if($pass1 == $pass2){
            $pass=$POST['pass'];
        }
        else{
        echo "<script>";
        echo "alert('Password did not match!');";
        echo "</script>";
        die();

        }
        session_start();
        $_SESSION['email'] = $email;
        $_SESSION['pass'] =$pass1;
        $_SESSION['name'] =$name;
        

		$result =$connection->query("INSERT INTO userinfo (name,email,pass) VALUES ('$name', '$email','$pass1')"); 
        if($result === true){
            header('location:../home.php');
        exit;
        }else{
            echo "Something went wrong";
        }
    }
?>