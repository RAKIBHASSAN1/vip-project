<?php 
	session_start();
	$mysql = new mysqli('localhost', 'root', '', 'gg');

	// initialize variables
	$give = "";
	$get = "";
	
	

	if (isset($_POST['post'])) {
		$give = $_POST['give'];
        $get = $_POST['get'];
        $status = $_POST['note'];
        $date = date("Y-m-d H:i:s");
        $email = $_SESSION['email'];
        $name = $_SESSION['name'];
        $result = $mysql->query("INSERT INTO posts (name,give,gett,status,email,time) VALUES ('$name','$give','$get','$status','$email','$date')"); 
        if($result === true){ 
		    header('location:../home.php');
        }else{
            echo "Something is wrong";
        }

        
        

		
		
	}