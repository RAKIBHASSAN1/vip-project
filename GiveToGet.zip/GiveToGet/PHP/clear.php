<?php

$mysql = new mysqli('localhost', 'root', '', 'gg');

if (isset($_GET['cle'])) {
	$id = $_GET['cle'];
	$mysql->query("DELETE FROM notify WHERE id=$id");
	header('location:../notification.php');
}
?>