-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2019 at 06:37 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinecourse`
--

-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

CREATE TABLE `sign_up` (
  `id` int(100) NOT NULL,
  `fristname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `usertype` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sign_up`
--

INSERT INTO `sign_up` (`id`, `fristname`, `lastname`, `email`, `usertype`, `department`, `username`, `password`) VALUES
(1, 'Ibrahim', 'Hasan', 'ami@gmail.com', 'student', 'cse', 'CSE06000000', 'ami321'),
(2, 'peter', 'parter', 'peter@gmail.com', 'student', 'cse', 'CSE06000001', 'ami321');

-- --------------------------------------------------------

--
-- Table structure for table `sub_registration`
--

CREATE TABLE `sub_registration` (
  `id` int(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `trimester` varchar(100) NOT NULL,
  `choose_sub1` varchar(100) NOT NULL,
  `choose_sub2` varchar(100) NOT NULL,
  `choose_sub3` varchar(100) NOT NULL,
  `choose_sub4` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_registration`
--

INSERT INTO `sub_registration` (`id`, `department`, `username`, `trimester`, `choose_sub1`, `choose_sub2`, `choose_sub3`, `choose_sub4`, `password`) VALUES
(2, 'CSE', 'CSE06000000', 'Summer 2019', 'CSI 453', 'CSI 313', 'CSI 314', 'CSI 483', 'ami321'),
(3, 'cse', 'CSE06000000', '', 'CSI 217', 'CSE 133', 'CSE 133', 'CSI 412', 'ami321');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sign_up`
--
ALTER TABLE `sign_up`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_registration`
--
ALTER TABLE `sub_registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sign_up`
--
ALTER TABLE `sign_up`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sub_registration`
--
ALTER TABLE `sub_registration`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
