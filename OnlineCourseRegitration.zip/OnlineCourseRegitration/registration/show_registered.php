<!DOCTYPE html>

<head>
<link rel="stylesheet" href="css\style.css" type="text/css">
 <link rel="icon" href="images\logo2.png" type="image/png" sizes="16x16"> 

<title>course-Registration of SUB</title>
</head>

<body>
<div> 
</div>

        <div id="maincontent">

                <div id="headermain">
                
                <div id="headercover" style="padding: 10px 0;">
                
                <div id="logo">
                <img src="images\logo2.png" height="55"> 
                </div>

                <div class="menu">
                                <ul>
                                   <li><a href="registration.html">Home</a></li>
                                            <li> <a href="#">About SUB</a>
                                          <li> <a href="#">Academics</a></li>
                                      <li><a class="active" href="registration.html">Course Registration</a></li>
                                      <li> <a href="#">Research</a>
                                        <li><a href="enroll-history">Enroll History</a></li>
                                        <li> <a href="#">Media</a></li>
                                      <li><a href="index.php">Logout</a></li>
        </ul>
        </div>

                <div id="headerright">

                <h2>Stamford Unversity Bangladesh</h2>
                <span>Rrgistered Course Home</span>
                </div>
                </div>
                
                <div id="subheadercover" align="center">
                
                <marquee behavior="ALTERNATE">Rrgistered Course Home!</marquee>
                
                </div>
                
                </div>
    
                
<p></p>
<p></p>
<div id="content">
        <h3></h3>
<form action="registered_input.php" method="post">
        <table border="0" cellpadding="2" cellspacing="0" align="center" id="logintable">
        <tr>

        <td>User ID</td>
        
        <td></td>
        
        <td><input type="text" placeholder="ex:CSE00000000" required autocomplete="off"  name="username" id="username"></td>
        
        </tr>
<tr>
<tr>

        <td>Password</td>
        
        <td></td>
        
        <td><input type="password" name="password" required autocomplete="off"  id="inputpassword"></td>
        
        </tr>
        <tr>

<td></td>

<td></td>

<td><input type="submit" name="registered_sub" value="Show" id="registered_subj"></td>
     
<td></td>

</tr>

</table>
</form>



</div>



<div id="footer">
    &copy; 2019 SUB, All Rights Reserved. Maintained by Stamford Unversity Bangladesh .
    </div>
    </div>

    </body>
    
    </html>