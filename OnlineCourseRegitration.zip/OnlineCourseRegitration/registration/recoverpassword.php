﻿
<!DOCTYPE html>


<head>
<link rel="stylesheet" href="css\style.css" type="text/css">
 <link rel="icon" href="images\logo2.png" type="image/png"height="55" > 

<title>coursee-Registration of SUB</title>
</head>
<body>

<div id="maincontent">

<div id="headermain">

<div id="headercover" style="padding: 10px 0;">

<div id="logo">
<img src="images\logo2.png" height="55"> 
</div>
<div id="headerright">
<h2>Stamford University Bangladesh</h2>
<span>Online Course Registration Portal</span>
</div>
</div>

<div id="subheadercover" align="center">

<marquee behavior="ALTERNATE">Welcome to Online Course Registration Portal !</marquee>

</div>

</div>

<div id="content">

<h3>Recover your Password</h3>

<form action="recinput.php" method="post">

<table border="0" cellpadding="2" cellspacing="0" align="center" id="logintable">

<tr>
<td>User Type</td>
<td></td>
<td><select name="usertype">
<option value="student">Student</option>
<option value="teacher">Teacher</option>
<option value="admin">Admin</option>

</select></td>
</tr>

<tr>
<td>Email Address</td>
<td></td>
<td><input type="text" placeholder="Email Address" name="email" id="email"></td>
</tr>

<tr>
<td></td>
<td></td>
<td><input style="width: auto !important;" type="submit" name="userlogin" value="Recover Password" id="userloginbutton"></td>
</tr>
</table>
</form>
</div>


<div id="footer">
&copy; 2019 SUB, All Rights Reserved. Maintained by Stamford Unversity Bangladesh .
</div>

</div> 

</body>

</html>