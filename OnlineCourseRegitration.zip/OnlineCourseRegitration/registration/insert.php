
<?php
$mysqli = new mysqli("localhost", "root", "", "onlinecourse");
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
if (isset($_POST['userSignUp'])){


$fristname =$_POST['fristname'];
$lastname =$_POST['lastname'];
$email =$_POST['email'];
$usertype = $_POST['usertype'];
$department = $_POST['department'];
$username = $_POST['username'];
$password =$_POST['password'];

 
$sql = "INSERT INTO sign_up(fristname, lastname, email, usertype, department, username, password) 
 VALUES ('$fristname', '$lastname', '$email', '$usertype', '$department', '$username', '$password')";

if($mysqli->query($sql) === true){
    echo "Records inserted successfully.";
    header("Location: index.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
}
}
$mysqli->close();
?>

