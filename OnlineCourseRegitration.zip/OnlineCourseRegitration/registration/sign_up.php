
<DOCTYPE! html>
        <head>
            <link rel="stylesheet" href="css\style.css" type="text/css">
            
            <script type="text/javascript" src="js\jquery-1.6.1.min.js"></script>
            
             <link rel="icon" href="images\logo2.png" type="image/png" sizes="16x16"> 
            
            <title>e-Registration of SUB</title>
            </head>
        <body>

            <div id="maincontent">
                <div id="headermain">
                    <div id="headercover" style="padding: 10px 0;">
                        <div id="logo">
                            <img src="images\logo2.png" height="55"> 
                          </div>
                          <div id="headerright">
                          <h2>Stamford Unversity Bangladesh</h2>
<span>Online Course Registration Portal</span>
</div>
</div>
                          <div id="subheadercover" align="center">

                              <marquee behavior="ALTERNATE">Welcome to Online Course Registration Portal !</marquee>
                              
                              </div>
                              
                              </div>
                              <div id="content">
                                  <h3>Sign UP Information</h3>
                                  <h1>Create Account</h1>
     <form action="insert.php" method="post">
         <table border="0" cellpadding="2" cellspacing="0" align="center" id="logintable">
                  <tr>
 
    <div class="tab-content">
      <div id="create_account">   
       
  
        
        
         
        <tr>
          <td>Frist Name<span class="req"></span> </td>         
          <td></td>          
          <td><input type="text"required name="fristname"></td>         
          </tr>
		  
          <tr>
            <td>Last Name<span class="req"></span> </td>         
            <td></td>          
            <td><input type="text"required name="lastname"></td>         
            </tr>
      
            
            <tr>
              <td>Email Address<span class="req"></span> </td>         
              <td></td>          
              <td><input type="email" placeholder="Enter Email" required name="email"></td>         
              </tr>             
          <tr>

              <td>User Type</td>
              
              <td></td>
              
              <td><select name="usertype">
              
              <option value="1">Student</option>
              <option value="2">Teacher</option>
              <option value="3">Admin</option>
              
              
              
              
              
              </select></td>
              
              </tr>
              <tr>

                <td>Department</td>
                
                <td></td>
                
                <td><select name="department">
                
                <option value="1">CSE</option>
                <option value="2">EEE</option>
                <option value="3">CNN</option>
                
                
                
                
                
                
                </select></td>
                
                </tr>

        <tr>

          <td>User ID<span class="req"></span> </td>
          
          <td></td>
          
          <td><input type="id" placeholder="ex:CSE00000000" required name="username" id="username"></td>
          
          </tr>
 <tr>
<td>Set A Password</td>
<td></td>
<td><input type="password" required  name="password" id="inputpassword"> </td>

</tr>
  
<tr>

  <td></td>
  
  <td></td>
  
  <td><input type="submit" name="userSignUp" value="SignUp" id="userSignUpbutton"></td>

  <td></td>

<td></td>

  <td><a href="index.php" style="color: #da70d8; font-weight: bold;">Already a member?</a></td>
  </tr>
</table>
  
</form>
</div>

<div id="footer">
    &copy; 2019 SUB, All Rights Reserved. Maintained by Stamford Unversity Bangladesh .
    </div>
  </div> 
</body>

</html>