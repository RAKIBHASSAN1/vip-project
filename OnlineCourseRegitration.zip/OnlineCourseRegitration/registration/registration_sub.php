
<?php
$mysqli = new mysqli("localhost", "root", "", "onlinecourse");
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
if (isset($_POST['usercourseregistration'])){


$department = $_POST['department'];
$username = $_POST['username'];
$trimester =$_POST['trimester'];
$choose_sub1 =$_POST['choose_sub1'];
$choose_sub2 =$_POST['choose_sub2'];
$choose_sub3 =$_POST['choose_sub3'];
$choose_sub4 =$_POST['choose_sub4'];
$password =$_POST['password'];

 
$sql = "INSERT INTO sub_registration(department, username, trimester, choose_sub1, choose_sub2, choose_sub3, choose_sub4, password) 
 VALUES ('$department', '$username', '$trimester', '$choose_sub1', '$choose_sub2', '$choose_sub3', '$choose_sub4', '$password')";

if($mysqli->query($sql) === true){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
}
}
$mysqli->close();
?>
