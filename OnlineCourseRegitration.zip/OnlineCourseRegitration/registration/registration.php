<!DOCTYPE html>

<head>
<link rel="stylesheet" href="css\style.css" type="text/css">
 <link rel="icon" href="images\logo2.png" type="image/png" sizes="16x16"> 

<title>course-Registration of SUB</title>
</head>

<body>
<div> 
</div>

        <div id="maincontent">

                <div id="headermain">
                
                <div id="headercover" style="padding: 10px 0;">
                
                <div id="logo">
                <img src="images\logo2.png" height="55"> 
                </div>

                <div class="menu">
                                <ul>
                                   <li><a href="registration.html">Home</a></li>
                                            <li> <a href="#">About SUB</a>
                                          <li> <a href="#">Academics</a></li>
                                      <li><a class="active" href="registration.html">Course Registration</a></li>
                                      <li> <a href="#">Research</a>
                                        <li><a href="enroll-history">Enroll History</a></li>
                                        <li> <a href="#">Media</a></li>
                                      <li><a href="index.php">Logout</a></li>
        </ul>
        </div>

                <div id="headerright">

                <h2>Stamford Unversity Bangladesh</h2>
                <span>Online Course Registration Portal</span>
                </div>
                </div>
                
                <div id="subheadercover" align="center">
                
                <marquee behavior="ALTERNATE">Welcome to Online Course Registration Portal !</marquee>
                
                </div>
                
                </div>
    
                
<p></p>
<p></p>
<div id="content">
        <h3>Registration Information</h3>
<form action="registration_sub.php" method="post">
        <table border="0" cellpadding="2" cellspacing="0" align="center" id="logintable">
        <tr>
                        <td>Department</td>
                
                        <td></td>
                        
                        <td><select name="department">
                        
                        <option value="cse">CSE</option>
                        <option value="eee">EEE</option>
                        <option value="cnn">CNN</option>
                        
                        
                        
                        
                        
                        
                        </select></td>
                        
                        </tr>     
<tr>

        <td>User ID</td>
        
        <td></td>
        
        <td><input type="text" placeholder="ex:CSE00000000" required autocomplete="off"  name="username" id="username"></td>
        
        </tr>
<tr>

<td>Select Trimester</td>

<td></td>

<td><select name="trimester" id="trimester" style="width:150px;">
                <option value="">Select Trimester</option>
                <option value="Fall 2022">Summer 2022</option>
                <option value="Summer 2022">Summer 2022</option>
                <option value="Spring 2022">Spring 2022</option>
                <option value="Fall 2021">Fall 2021</option>
                <option value="Summer 2021">Summer 2021</option>
                <option value="Spring 2021">Spring 2021</option>
                <option value="Fall 2020">Fall 2020</option>
                <option value="Summer 2020">Summer 2020</option>
                <option value="Spring 2020">Spring 2020</option>
                <option value="Fall 2019">Fall 2019</option>
                <option value="Summer 2019">Summer 2019</option>
                <option value="Spring 2019">Spring 2019</option>
                 </select></td>

</tr>
       

                    <td> Select Subject 1 :</td>
                  <td></td>
                  <td><select name="choose_sub1" id="trimester" style="width:150px;">
                         <option value="">choose subject 1</option>
                         <option value="CSI 453">CSI 453</option>
                         <option value="CSI 313">CSI 313</option>
                         <option value="CSI 314">CSI 314</option>
                         <option value="CSI 413">CSI 413</option>
                         <option value="CSI 483">CSI 483</option>
                         <option value="CSI 311">CSI 311</option>
                         <option value="CSI 312">CSI 312</option>
                         <option value="CSI 411">CSI 411</option>
                         <option value="CSI 412">CSI 412</option>
                         <option value="CSI 223">CSI 223</option>
                        <option value="CSI 224">CSI 224</option>
                        <option value="CSI 315">CSI 315</option>
                        <option value="CSE 214">CSE 214</option>
                        <option value="CSI 217">CSI 217</option>
                        <option value="CSE 213">CSE 213</option>
                        <option value="CSE 133">CSE 133</option>
                        <option value="CSE 134">CSE 134</option>
                        <option value="CSI 221">CSI 221</option>
                       <option value="EEE 195">EEE 195</option>
                       <option value="MATH 135">MATH 135</option>
                        </select></td>
                                
                                
                 </tr>
                 
                  <tr>
       

                    <td> Select Subject 2:</td>
                  <td></td>
                  <td><select name="choose_sub2" id="trimester" style="width:150px;">
                         <option value="">choose subject 2</option>
                         <option value="CSI 453">CSI 453</option>
                         <option value="CSI 313">CSI 313</option>
                         <option value="CSI 314">CSI 314</option>
                         <option value="CSI 413">CSI 413</option>
                         <option value="CSI 483">CSI 483</option>
                         <option value="CSI 311">CSI 311</option>
                         <option value="CSI 312">CSI 312</option>
                         <option value="CSI 411">CSI 411</option>
                         <option value="CSI 412">CSI 412</option>
                         <option value="CSI 223">CSI 223</option>
                        <option value="CSI 224">CSI 224</option>
                        <option value="CSI 315">CSI 315</option>
                        <option value="CSE 214">CSE 214</option>
                        <option value="CSI 217">CSI 217</option>
                        <option value="CSE 213">CSE 213</option>
                        <option value="CSE 133">CSE 133</option>
                        <option value="CSE 134">CSE 134</option>
                        <option value="CSI 221">CSI 221</option>
                       <option value="EEE 195">EEE 195</option>
                       <option value="MATH 135">MATH 135</option>
                        </select></td>
                                
                                
                 </tr>
 <tr>
       

         <td> Select Subject 3 :</td>
         <td></td>
          <td><select name="choose_sub3" id="trimester" style="width:150px;">
         <option value="">choose subject 3</option>
         <option value="CSI 453">CSI 453</option>
         <option value="CSI 313">CSI 313</option>
         <option value="CSI 314">CSI 314</option>
         <option value="CSI 413">CSI 413</option>
         <option value="CSI 483">CSI 483</option>
          <option value="CSI 311">CSI 311</option>
         <option value="CSI 312">CSI 312</option>
         <option value="CSI 411">CSI 411</option>
          <option value="CSI 412">CSI 412</option>
          <option value="CSI 223">CSI 223</option>
        <option value="CSI 224">CSI 224</option>
         <option value="CSI 315">CSI 315</option>
         <option value="CSE 214">CSE 214</option>
         <option value="CSI 217">CSI 217</option>
         <option value="CSE 213">CSE 213</option>
         <option value="CSE 133">CSE 133</option>
         <option value="CSE 134">CSE 134</option>
          <option value="CSI 221">CSI 221</option>
         <option value="EEE 195">EEE 195</option>
         <option value="MATH 135">MATH 135</option>
          </select></td>
                                            
                                            
     </tr>      
     
     

     <tr>
       

                <td> Select Subject 4 :</td>
              <td></td>
              <td><select name="choose_sub4" id="trimester" style="width:150px;">
                     <option value="">choose subject 4</option>
                     <option value="CSI 453">CSI 453</option>
                     <option value="CSI 313">CSI 313</option>
                     <option value="CSI 314">CSI 314</option>
                     <option value="CSI 413">CSI 413</option>
                     <option value="CSI 483">CSI 483</option>
                     <option value="CSI 311">CSI 311</option>
                     <option value="CSI 312">CSI 312</option>
                     <option value=">CSI 411">CSI 411</option>
                     <option value="CSI 412">CSI 412</option>
                     <option value="CSI 223">CSI 223</option>
                    <option value="CSI 224">CSI 224</option>
                    <option value="CSI 315">CSI 315</option>
                    <option value="CSE 214">CSE 214</option>
                    <option value="CSI 217">CSI 217</option>
                    <option value="CSE 213">CSE 213</option>
                    <option value=">CSE 133">CSE 133</option>
                    <option value="CSE 134">CSE 134</option>
                    <option value="CSI 221">CSI 221</option>
                   <option value="EEE 195">EEE 195</option>
                   <option value="MATH 135">MATH 135</option>
                    </select></td>
                            
                            
             </tr>

<tr>

        <td>Password</td>
        
        <td></td>
        
        <td><input type="password" name="password" required autocomplete="off"  id="inputpassword"></td>
        
        </tr>

        <tr>

                <tr>

                        <td></td>
                        
                        <td></td>
                        
                        <td><input type="submit" name="usercourseregistration" value="Submit" id="usercourseregistration"></td>
                        <td><button class="button"><a href="show_registered.php" style="color: white">Registered Subject</a> </button></td>
                             
                        <td></td>
                
                </tr>



</table>
</form>



</div>



<div id="footer">
    &copy; 2019 SUB, All Rights Reserved. Maintained by Stamford Unversity Bangladesh .
    </div>
    </div>

    </body>
    
    </html>