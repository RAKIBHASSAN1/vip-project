
<!DOCTYPE html>

<head>
<link rel="stylesheet" href="css\style.css" type="text/css">
 <link rel="icon" href="images\logo2.png" type="image/png" sizes="16x16"> 

<title>course-Registration of SUB</title>
</head>

<body>
<div> 
</div>

        <div id="maincontent">

                <div id="headermain">
                
                <div id="headercover" style="padding: 10px 0;">
                
                <div id="logo">
                <img src="images\logo2.png" height="55"> 
                </div>

                <div class="menu">
                                <ul>
                                   <li><a href="registration.html">Home</a></li>
                                            <li> <a href="#">About SUB</a>
                                          <li> <a href="#">Academics</a></li>
                                      <li><a class="active" href="registration.html">Course Registration</a></li>
                                      <li> <a href="#">Research</a>
                                        <li><a href="enroll-history">Enroll History</a></li>
                                        <li> <a href="#">Media</a></li>
                                      <li><a href="index.php">Logout</a></li>
        </ul>
        </div>

                <div id="headerright">

                <h2>Stamford Unversity Bangladesh</h2>
                <span>Registered Subject Course</span>
                </div>
                </div>
                
                <div id="subheadercover" align="center">
                
                <marquee behavior="ALTERNATE">Rrgistered Subject Course! </marquee>
                
                </div>
                
                </div>       
 <body>




<?php	
	session_start();
    $mysqli = new mysqli('localhost', 'root', '', 'onlinecourse');
    
    if($mysqli === false){
        die("ERROR: Could not connect. " . $mysqli->connect_error);
    }
	
	$usertype = $username = $password = "";
	$usertype_err = $username_err = $password_err = "";
	if(isset($_POST['registered_sub'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
    
      
        
        $sql="SELECT * FROM sub_registration  WHERE  username = '$username' AND  password = '$password'  LIMIT 1";
			if($result = $mysqli->query($sql))
			{
                if($result->num_rows > 0){
			echo "<p style=' margin-top: 50px;font-size:30px;margin-left:200px;float:left'></p>"."<table border=3>";
                echo "<tr style='background-color:green;color:white'>";
                echo "<th style='width:90px;'>User ID</th>";
                echo "<th style='width:90px;'>Department</th>";
                echo "<th style='width:90px;'>Trimester</th>";
                echo "<th style='width:70px'>Subject 1</th>";
                echo "<th style='width:70px'>Subject 2</th>";
                echo "<th style='width:70px'>Subject 3</th>";
                echo "<th style='width:70px'>Subject 4</th>";
              
                echo "</tr>";
            while($row = $result->fetch_array()){
                echo "<tr>";
                    echo "<td style='text-align:center;background-color:blue;color:white'>" . $row['username'] . "</td>";
                    echo "<td style='text-align:center;background-color:blue;color:white'>" . $row['department'] . "</td>";
                    echo "<td  style='text-align:center;background-color:blue;color:white'>" . $row['trimester'] . "</td>";
                    echo "<td  style='text-align:center;background-color:blue;color:white'>" . $row['choose_sub1'] . "</td>";
                    echo "<td  style='text-align:center;background-color:blue;color:white'>" . $row['choose_sub2'] . "</td>";
                    echo "<td  style='text-align:center;background-color:blue;color:white'>" . $row['choose_sub3'] . "</td>";
                    echo "<td  style='text-align:center;background-color:blue;color:white'>" . $row['choose_sub4'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
            $result->free();
        } else{
            echo "No records matching your query were found.";
        }
    } else{
        echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
    }
			
			
      
    }
    $mysqli->close();
  
    ?>


<div id="footer">
    &copy; 2019 SUB, All Rights Reserved. Maintained by Stamford Unversity Bangladesh .
    </div>
    </div>

    </body>
<html>


