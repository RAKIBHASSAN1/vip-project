

<?php
session_start();
$mysqli = new mysqli('localhost', 'root', '', 'userregistration');

if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}


$userid=$firstname=$lastname=$address= $email=$phonenumber= $bed=$bed1=$bed2= $bed3= $payment="";

$userid_err=$firstname_err=$lastname_err=$address_err=$email_err=$phonenumber_err=$bed_err=$bed1_err=$bed2_err=$bed3_err= $payment_err="";
if(isset($_POST['save'])){
  $userid = $_POST['userid'];
   $firstname =$_POST['firstname'];
$lastname = $_POST['lastname'];
$address =$_POST['address'];
$email =$_POST['email'];
$phonenumber = $_POST['phonenumber'];
$bed = $_POST['bed'];
$bed1 = $_POST['bed1'];
$bed2 = $_POST['bed2'];
$bed3 = $_POST['bed3'];
$payment = $_POST['payment'];

  
$mysqli->query("INSERT INTO managerreceaption (userid, firstname,lastname,address,email,phonenumber,bed,bed1,bed2,bed3,payment) VALUES ('$userid','$firstname','$lastname','$address','$email','$phonenumber','$bed','$bed1','$bed2','$bed3','$payment')");

}
if(isset($_GET['userid']))
{
    $userid = isset($_GET['userid']) ? $_GET['userid'] : '';
$query="DELETE FROM managerreceaption where userid='$userid'";
$data=mysqli_query($mysqli,$query);
}



    $mysqli->close();

?>


<!DOCTYPE html>

<html>

<head>
      <title>Profile Homepage</title>
    <link href="styles/userprofile.css"rel="stylesheet" type="text/css"> 

</head>
<body>

      <header>
      <div class="main">
            <ul>
                <li class ="active"><a href="managerprofile.php"target="blank">Receaption</a></li>             
                <li class="page"><a href="staffschedule.php"target="blank">Set staff schedeul</a></li>
               
            </ul>     
        </div> 
           
           
      </header> 
      <br>
      <div class="box">
          <form action="managerprofile.php" method="post">
            <br><br>
              <div id="r0">
              <h1>Room Booking</h1>
                  <label for="user_id">User Id: </label>
                  <input type="text" id="user_id" name="userid"required="">
               </div>
               <div id="r1">
                  <label for="name">First Name: </label>
                  <input type="text" id="name" name="firstname"required="">
               </div>
               <div id="r2">
                  <label for="name">Last Name: </label>
                  <input type="text" id="lastname" name="lastname"required="">
               </div>
               <div id="r3">
                  <label for="address">Address: </label>
                  <input type="text" id="address" name="address"required="">
               </div>
               <div id="r4">
                <label for="email">Email: </label>
                <input type="email" id="email" name="email"required="">
              </div>
              <div id="r5">
              <label for="phone">Phone: </label>
                <input type="text" id="phone" name="phonenumber"required="">
      </div> 
              

          <div id="bed">            
              <label for="bed">
                Select Bed Type:
              </label>
              <select id="bed" name="bed">
                <option value="single">Single</option>
                <option value="double">Double</option>
              </select>          
         </div>

         <div id="bed1">        
              <label for="accommodation">
                <span>Accommodation:</span>
              </label>
              <select id="accommodation" name="bed1"required="">
                <option value="premium">Premium</option>
                <option value="general">General</option>
              </select>        
         </div>

        <div id="bed2">   
              <label for="date">
                Date of booking:
              </label>
             <input type="date" id="date" name="bed2"required="">      
       </div>


       <div id="bed3">      
              <label for="date">
                Date of leaving:
              </label>
              <input type="date" id="date" name="bed3"required="">       
       </div>


       <div id="bed4">     
              <label for="payment">
               Select Payment Option:
              </label>
              <select id="payment" name="payment"required="">
                <option value="Credit">Credit</option>
                <option value="Debit">Debit</option>
              </select>         
        </div>

             <div id="r6">
                  <button type="save" name="save">Submit</button>
             </div> 

                  
        </form> 
     </div> 
          
     <div id="l1">
     <?php
    $mysqli = new mysqli('localhost', 'root', '', 'userregistration');

    if($mysqli === false){
        die("ERROR: Could not connect. " . $mysqli->connect_error);
    }
        
       $sql = "SELECT * FROM managerreceaption";
       if($result = $mysqli->query($sql)){
           
           if($result->num_rows > 0){
               
               echo "<p style=' margin-top:10px;font-size:30px;margin-left:-400px;'></p>"."<table border=3>";
                   echo "<tr style='background-color:green;color:white'>";
                       echo "<th style='width:70px;font-size:10px;'>User Id</th>";
                       echo "<th style='width:50px;font-size:10px;'>First Name </th>";
                       echo "<th style='width:50px;font-size:10px;'>Last Name</th>";
                       echo "<th style='width:50px;font-size:10px;'>Address </th>";
                       echo "<th style='width:50px;font-size:10px;'>Email </th>";
                       echo "<th style='width:90px;font-size:10px;'>Phone Number </th>";
                       echo "<th style='width:90px;font-size:10px;'>Bed Type </th>";
                       echo "<th style='width:90px;font-size:10px;'>Accommodation </th>";
                       echo "<th style='width:90px;font-size:10px;'>Date of booking </th>";
                       echo "<th style='width:90px;font-size:10px;'>Date of leaving </th>";
                       echo "<th style='width:90px;font-size:10px;'>Payment Option </th>";
                       echo "<th style='width:90px;font-size:10px;'>Action </th>";
                   echo "</tr>";
               while($row = $result->fetch_array()){
                   echo "<tr>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:10px;'>" . $row['userid'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:10px;'>" . $row['firstname'] . "</td>";
                       echo "<td  style='text-align:center;background-color:blue;color:white;font-size:10px;'>" . $row['lastname'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:10px;'>" . $row['address'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;width:50px;font-size:10px;'>" . $row['email'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:10px;'>" . $row['phonenumber'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:10px;'>" . $row['bed'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:10px;'>" . $row['bed1'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:10px;'>" . $row['bed2'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:10px;'>" . $row['bed3'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:10px;'>" . $row['payment'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white'>" . "<a href='managerprofile.php?userid=$row[userid]'onclick='checkdelete()'style='color:white;text-decoration:none;'>"."Delete" ."</a>". "</td>";
                       echo "</tr>";
               }
               echo "</table>";
               $result->free();
           } else{
       
           }
       } else{
           echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
       }
     
     ?>
 </div>
            
</body>    

</html>
<script>

$(function () {
            $("#datepicker").datepicker({ dateFormat: "yy-mm-dd", changeMonth: true, changeYear: true });
        });
        function checkdelete 
{
    return confirm('Are Sure Remove the data?');
}
  </script>
    
