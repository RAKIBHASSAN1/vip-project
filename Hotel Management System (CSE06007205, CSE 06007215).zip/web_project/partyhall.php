
<?php
session_start();
$mysqli = new mysqli('localhost', 'root', '', 'userregistration');

if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}


$userid=$firstname=$lastname=$address= $email=$phonenumber=$bed=$bed2=$payment="";

$userid_err=$firstname_err=$lastname_err=$address_err=$email_err=$phonenumber_err=$bed_err=$bed2_err=$payment_err="";
if(isset($_POST['save'])){
  $userid = $_POST['userid'];
   $firstname =$_POST['firstname'];
$lastname = $_POST['lastname'];
$address =$_POST['address'];
$email =$_POST['email'];
$phonenumber = $_POST['phonenumber'];
$bed = $_POST['bed'];
$bed2 = $_POST['bed2'];
$payment = $_POST['payment'];

  
$mysqli->query("INSERT INTO partyhall (userid, firstname,lastname,address,email,phonenumber,bed,bed2,payment) VALUES ('$userid','$firstname','$lastname','$address','$email','$phonenumber','$bed','$bed2','$payment')");

}
if(isset($_GET['userid']))
{
    $userid = isset($_GET['userid']) ? $_GET['userid'] : '';
$query="DELETE FROM foodorder where userid='$userid'";
$data=mysqli_query($mysqli,$query);
}



    $mysqli->close();

?>







<!DOCTYPE html>

<html>

<head>
      <title>partyhall</title>
    <link href="styles/partyhall.css"rel="stylesheet" type="text/css"> 

</head> 
      <br>
      <div class="box">
          <form action="partyhall.php" method="post">
            <br><br>
              <div id="r0">
              <h1>party Hall Booking</h1>
                  <label for="user_id">User Id: </label>
                  <input type="text" id="user_id" name="userid"required="">
               </div>
               <div id="r1">
                  <label for="name">First Name: </label>
                  <input type="text" id="name" name="firstname"required="">
               </div>
               <div id="r2">
                  <label for="name">Last Name: </label>
                  <input type="text" id="lastname" name="lastname"required="">
               </div>
               <div id="r3">
                  <label for="address">Address: </label>
                  <input type="text" id="address" name="address"required="">
               </div>
               <div id="r4">
                <label for="email">Email: </label>
                <input type="email" id="email" name="email"required="">
              </div>
              <div id="r5">
              <label for="phone">Phone: </label>
                <input type="text" id="phone" name="phonenumber"required="">
      </div> 
              

          <div id="bed">            
              <label for="bed">
                Select Days:
              </label>
              <select id="bed" name="bed"required="">
                <option value="single">1 Days</option>
                <option value="double">2 Days</option>
                <option value="double">3 Days</option>
                <option value="double">5 Days</option>
              </select>          
         </div>

      

        <div id="bed2">   
              <label for="date">
                Date of booking:
              </label>
             <input type="date" id="date" name="bed2"required="">      
       </div>




       <div id="bed4">     
              <label for="payment">
               Select Payment Option:
              </label>
              <select id="payment" name="payment"required="">
                <option value="Credit">Credit</option>
                <option value="Debit">Debit</option>
              </select>         
        </div>

             <div id="r6">
                  <button type="save" name="save">Submit</button>
             </div> 

                  
        </form> 
     </div>     
     <br>

     <div id="l1">
     <?php
       $mysqli = new mysqli("localhost", "root", "", "userregistration");
 
       if($mysqli === false){
           die("ERROR: Could not connect. " . $mysqli->connect_error);
       }
        
       $sql = "SELECT * FROM partyhall";
       if($result = $mysqli->query($sql)){
           
           if($result->num_rows > 0){
               
               echo "<p style=' margin-top:10px;font-size:30px;margin-left:-400px;'></p>"."<table border=3>";
                   echo "<tr style='background-color:green;color:white'>";
                       echo "<th style='width:70px;font-size:10px;'>User Id</th>";
                       echo "<th style='width:50px;font-size:10px;'>First Name </th>";
                       echo "<th style='width:50px;font-size:10px;'>Last Name</th>";
                       echo "<th style='width:50px;font-size:10px;'>Address </th>";
                       echo "<th style='width:50px;font-size:10px;'>Email </th>";
                       echo "<th style='width:90px;font-size:10px;'>Phone Number </th>";
                       echo "<th style='width:90px;font-size:10px;'>Select item </th>";              
                       echo "<th style='width:90px;font-size:10px;'>Date of booking </th>";             
                       echo "<th style='width:90px;font-size:10px;'>Select Payment Option </th>";
                       echo "<th style='width:90px;font-size:10px;'>Action </th>";
                   echo "</tr>";
               while($row = $result->fetch_array()){
                   echo "<tr>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['userid'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['firstname'] . "</td>";
                       echo "<td  style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['lastname'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['address'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;width:50px;font-size:15px;'>" . $row['email'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['phonenumber'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['bed'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['bed2'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['payment'] . "</td>";
                       echo "<td style='text-align:center;background-color:blue;color:white'>" . "<a href='partyhall.php?userid=$row[userid]'onclick='checkdelete()'style='color:white;text-decoration:none;'>"."Delete" ."</a>". "</td>";
                       echo "</tr>";
               }
               echo "</table>";
               $result->free();
           } else{
       
           }
       } else{
           echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
       }
     
     ?>
     </div>
            
</body>    

</html>
<script>

$(function () {
            $("#datepicker").datepicker({ dateFormat: "yy-mm-dd", changeMonth: true, changeYear: true });
        });
        function checkdelete 
{
    return confirm('Are Sure Remove the data?');
}
  </script>

