<?php
    $mysqli = new mysqli("localhost", "root", "", "userregistration");

    if($mysqli === false){
        die("ERROR: Could not connect. " . $mysqli->connect_error);
    }
     
    $sql = "SELECT * FROM staffschedule";
    if($result = $mysqli->query($sql)){
        
        if($result->num_rows > 0){
            
            echo "<p style=' margin-top:10px;font-size:30px;margin-left:-400px;'></p>"."<table border=3>";
                echo "<tr style='background-color:green;color:white'>";
                    echo "<th style='width:70px;font-size:10px;'>User Id</th>";
                    echo "<th style='width:50px;font-size:10px;'>First Name </th>";
                    echo "<th style='width:50px;font-size:10px;'>Last Name</th>";              
                    echo "<th style='width:90px;font-size:10px;'>Date of booking </th>";             
                   
            while($row = $result->fetch_array()){
                echo "<tr>";
                    echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['userid'] . "</td>";
                    echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['firstname'] . "</td>";
                    echo "<td  style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['lastname'] . "</td>";
                    echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['bed'] . "</td>";                  
                    echo "<td style='text-align:center;background-color:blue;color:white'>" . "<a href='staffschedule.php?userid=$row[userid]'onclick='checkdelete()'style='color:white;text-decoration:none;'>"."Delete" ."</a>". "</td>";
                    echo "</tr>";
            }
            echo "</table>";
            $result->free();
        } else{
    
        }
    } else{
        echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
    }
  
  ?>
  </div>
         
</body>    

</html>
<script>