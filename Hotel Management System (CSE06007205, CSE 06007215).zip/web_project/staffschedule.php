

<?php
session_start();
$mysqli = new mysqli('localhost', 'root', '', 'userregistration');

if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}


$userid=$firstname=$lastname=$bed="";

$userid_err=$firstname_err=$lastname_err=$bed_errr="";
if(isset($_POST['save'])){
  $userid = $_POST['userid'];
   $firstname =$_POST['firstname'];
$lastname = $_POST['lastname'];
$bed = $_POST['bed'];


  
$mysqli->query("INSERT INTO staffschedule (userid, firstname,lastname,bed) VALUES ('$userid','$firstname','$lastname','$bed')");

}
if(isset($_GET['userid']))
{
    $userid = isset($_GET['userid']) ? $_GET['userid'] : '';
$query="DELETE FROM staffschedule where userid='$userid'";
$data=mysqli_query($mysqli,$query);
}



    $mysqli->close();

?>

<!DOCTYPE html>

<html>

<head>
      <title>staffschedule</title>
    <link href="styles/staffschedule.css"rel="stylesheet" type="text/css"> 

</head>
<body>

           
           
      </header> 
      <br>
      <div class="box">
          <form action="staffschedule.php" method="post">
            <br><br>
              <div id="r0">
                  <label for="user_id">Staff Id: </label>
                  <input type="text" id="user_id" name="userid"required="">
               </div>
               <div id="r1">
                  <label for="name">User Id: </label>
                  <input type="text" id="name" name="firstname"required="">
               </div>
               <div id="r2">
                  <label for="name">Room number: </label>
                  <input type="text" id="lastname" name="lastname"required="">
               </div>

          <div id="bed">            
              <label for="bed">
               Shift:
              </label>
              <select id="bed" name="bed"required="">
                <option value="single">6 hours</option>
                <option value="double">12 hours</option>
              </select>          
         </div>


             <div id="r6">
                  <button type="save" name="save">Submit</button>
             </div> 

                  
        </form> 
     </div>     
     <div id="l1">

<?php
    $mysqli = new mysqli("localhost", "root", "", "userregistration");

    if($mysqli === false){
        die("ERROR: Could not connect. " . $mysqli->connect_error);
    }
     
    $sql = "SELECT * FROM staffschedule";
    if($result = $mysqli->query($sql)){
        
        if($result->num_rows > 0){
            
            echo "<p style=' margin-top:10px;font-size:30px;margin-left:-400px;'></p>"."<table border=3>";
                echo "<tr style='background-color:green;color:white'>";
                    echo "<th style='width:70px;font-size:10px;'>User Id</th>";
                    echo "<th style='width:50px;font-size:10px;'>First Name </th>";
                    echo "<th style='width:50px;font-size:10px;'>Last Name</th>";              
                    echo "<th style='width:90px;font-size:10px;'>Date of booking </th>";             
                   
            while($row = $result->fetch_array()){
                echo "<tr>";
                    echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['userid'] . "</td>";
                    echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['firstname'] . "</td>";
                    echo "<td  style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['lastname'] . "</td>";
                    echo "<td style='text-align:center;background-color:blue;color:white;font-size:15px;'>" . $row['bed'] . "</td>";                  
                    echo "<td style='text-align:center;background-color:blue;color:white'>" . "<a href='staffschedule.php?userid=$row[userid]'onclick='checkdelete()'style='color:white;text-decoration:none;'>"."Delete" ."</a>". "</td>";
                    echo "</tr>";
            }
            echo "</table>";
            $result->free();
        } else{
    
        }
    } else{
        echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
    }
  
  ?>
  </div>
         
</body>    

</html>
<script>