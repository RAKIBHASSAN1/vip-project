-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2019 at 07:37 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userregistration`
--

-- --------------------------------------------------------

--
-- Table structure for table `foodorder`
--

CREATE TABLE `foodorder` (
  `userid` int(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phonenumber` int(33) NOT NULL,
  `bed` varchar(44) NOT NULL,
  `bed2` date NOT NULL,
  `payment` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `foodorder`
--

INSERT INTO `foodorder` (`userid`, `firstname`, `lastname`, `address`, `email`, `phonenumber`, `bed`, `bed2`, `payment`) VALUES
(2222, 'aaaa', 'hasan', 'malibag', 'nahidh529@gmail.com', 119845144, 'double', '2019-04-03', 'Credit'),
(2147483647, 'First Name', 'hasan', 'dhaka', 'nh0595428@gmail.com', 119845144, 'single', '2019-04-17', 'Debit');

-- --------------------------------------------------------

--
-- Table structure for table `managerreceaption`
--

CREATE TABLE `managerreceaption` (
  `userid` int(100) NOT NULL,
  `firstname` int(20) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phonenumber` int(33) NOT NULL,
  `bed` varchar(44) NOT NULL,
  `bed1` varchar(55) NOT NULL,
  `bed2` date NOT NULL,
  `bed3` date NOT NULL,
  `payment` varchar(33) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `managerreceaption`
--

INSERT INTO `managerreceaption` (`userid`, `firstname`, `lastname`, `address`, `email`, `phonenumber`, `bed`, `bed1`, `bed2`, `bed3`, `payment`) VALUES
(1245, 0, 'hasan', 'dhaka', 'nh52225@gmail.com', 1718957252, 'double', 'general', '0000-00-00', '0000-00-00', 'Debit'),
(2222, 0, 'hasan', 'dhaka', 'nahidh29@gmail.com', 119845144, 'double', 'general', '0000-00-00', '0000-00-00', 'Credit'),
(2147483647, 0, 'bbbbb', 'dhaka', 'nahidh529@gmail.com', 119845144, 'double', 'premium', '0000-00-00', '0000-00-00', 'Debit');

-- --------------------------------------------------------

--
-- Table structure for table `partyhall`
--

CREATE TABLE `partyhall` (
  `userid` int(100) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phonenumber` int(33) NOT NULL,
  `bed2` date NOT NULL,
  `payment` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `partyhall`
--

INSERT INTO `partyhall` (`userid`, `firstname`, `lastname`, `address`, `email`, `phonenumber`, `bed2`, `payment`) VALUES
(2222, 'aaaa', 'hasan', 'dhaka', 'nahidh529@gmail.com', 119845144, '2019-04-17', 'Debit'),
(2147483647, 'nahid', 'hasan', 'dhaka', 'nahidh529@gmail.com', 23433, '2019-04-10', 'Debit');

-- --------------------------------------------------------

--
-- Table structure for table `pool`
--

CREATE TABLE `pool` (
  `userid` int(100) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phonenumber` int(33) NOT NULL,
  `bed` varchar(44) NOT NULL,
  `bed2` date NOT NULL,
  `payment` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pool`
--

INSERT INTO `pool` (`userid`, `firstname`, `lastname`, `address`, `email`, `phonenumber`, `bed`, `bed2`, `payment`) VALUES
(100, 'mushfiqrahman', 'hasan', 'dhaka', 'mmm@gmail.com', 23433, 'single', '0000-00-00', 'Debit'),
(1234, 'nahid', 'hasan', 'dhaka', 'hh2808094@gmail.com', 1718957252, 'double', '0000-00-00', 'Credit'),
(2147483647, 'b', 'bbbbb', 'dhaka', 'nh0595428@gmail.com', 119845144, 'single', '0000-00-00', 'Credit');

-- --------------------------------------------------------

--
-- Table structure for table `staffschedule`
--

CREATE TABLE `staffschedule` (
  `userid` int(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `bed` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffschedule`
--

INSERT INTO `staffschedule` (`userid`, `firstname`, `lastname`, `bed`) VALUES
(2147483647, 'b', 'hasan', 'single');

-- --------------------------------------------------------

--
-- Table structure for table `userbooking`
--

CREATE TABLE `userbooking` (
  `userid` int(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` int(100) NOT NULL,
  `bed` varchar(100) NOT NULL,
  `bed1` varchar(100) NOT NULL,
  `bed2` date NOT NULL,
  `bed3` date NOT NULL,
  `payment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userbooking`
--

INSERT INTO `userbooking` (`userid`, `firstname`, `lastname`, `address`, `email`, `phonenumber`, `bed`, `bed1`, `bed2`, `bed3`, `payment`) VALUES
(100, 'nahid', 'hasan', 'malibag', 'nahidh529@gmail.com', 119845144, 'double', 'general', '2019-04-02', '2019-04-30', 'Debit'),
(1234, 'nahid', 'hasan', 'dhaka', 'nh52225@gmail.com', 119845144, 'double', 'premium', '2019-04-17', '2019-04-24', 'Credit'),
(2222, 'b', 'hasan', '', '', 0, 'double', '', '0000-00-00', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `user` varchar(59) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`user`, `name`, `password`) VALUES
('', '3333', '1234'),
('', 'admin', '22'),
('', 'nahid1', '11111'),
('', 'user', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `usertable0`
--

CREATE TABLE `usertable0` (
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable0`
--

INSERT INTO `usertable0` (`name`, `password`) VALUES
('45', '123'),
('user', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `usertable2`
--

CREATE TABLE `usertable2` (
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable2`
--

INSERT INTO `usertable2` (`name`, `password`) VALUES
('staff', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `usertable3`
--

CREATE TABLE `usertable3` (
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable3`
--

INSERT INTO `usertable3` (`name`, `password`) VALUES
('manager', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `usertable4`
--

CREATE TABLE `usertable4` (
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable4`
--

INSERT INTO `usertable4` (`name`, `password`) VALUES
('admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `weddinghall`
--

CREATE TABLE `weddinghall` (
  `userid` int(100) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phonenumber` int(33) NOT NULL,
  `bed` varchar(44) NOT NULL,
  `bed2` date NOT NULL,
  `payment` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `weddinghall`
--

INSERT INTO `weddinghall` (`userid`, `firstname`, `lastname`, `address`, `email`, `phonenumber`, `bed`, `bed2`, `payment`) VALUES
(2222, 'b', 'hasan', 'dhaka', 'nahidh529@gmail.com', 23433, 'double', '2019-04-03', 'Debit'),
(2147483647, 'First Name', 'hasan', 'malibag', 'hh2808094@gmail.com', 23433, 'double', '2019-04-18', 'Debit');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `foodorder`
--
ALTER TABLE `foodorder`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `managerreceaption`
--
ALTER TABLE `managerreceaption`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `partyhall`
--
ALTER TABLE `partyhall`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `pool`
--
ALTER TABLE `pool`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `staffschedule`
--
ALTER TABLE `staffschedule`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `userbooking`
--
ALTER TABLE `userbooking`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `usertable0`
--
ALTER TABLE `usertable0`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `usertable2`
--
ALTER TABLE `usertable2`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `usertable3`
--
ALTER TABLE `usertable3`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `usertable4`
--
ALTER TABLE `usertable4`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `weddinghall`
--
ALTER TABLE `weddinghall`
  ADD PRIMARY KEY (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
