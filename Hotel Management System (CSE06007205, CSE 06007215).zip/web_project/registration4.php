<?php
session_start();
header ('location:login4.php');

$con= mysqli_connect('localhost','root','');

mysqli_select_db($con, 'userregistration');

$name= $_POST['user'];
$pass= $_POST['password'];

$s = " select * from usertable4 where name = '$name'";

$result2 = mysqli_query($con, $s);

$num = mysqli_num_rows($result2);
if($num == 1){
    echo "Username Already Taken";
}else{
    $reg= " insert into usertable4 (name, password) values ('$name' , '$pass')";
    mysqli_query($con, $reg);
    echo "Registration Successful";
}

?>