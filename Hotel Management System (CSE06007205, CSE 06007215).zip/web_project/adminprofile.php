<!DOCTYPE html>

<html>

<head>
      <title>Admin Homepage</title>
    <link href="styles/adminprofile.css"rel="stylesheet" type="text/css"> 

</head>
<body>
      <header>
            <div class="main">
            <ul>                 
                    <li class="dropdown">
                            <a class="dropbtn">Approve </a>
                            <div class="dropdown-content">
                              <a href="userroombook.php">USER Room Booking list</a>
                              <a href="userswimmingpool.php">USER swimmingpool Booking list </a>
                              <a href="userweddinghall.php">USER Wedding Hall Booking list</a>
                              <a href="userfoodorder.php">USER Food order list</a>
                            </div>
                    </li>
            </ul>
            </div>  
           
      </header> 
      <br>
      
      </body>
      </html>