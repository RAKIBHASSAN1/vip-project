<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<title>::. Build Bright University .::</title>
</head>

<body>
<div id="content">
	<div >
    	<img src="picture/00.jpg" width="805" height="308"  />
    </div>
    
    <div id="space"></div>
    
    <div id="question">
    	What do you know about North Capital University?
    </div>
    
    <div id="space"></div>
    
    <div style="text-indent:40px; text-align:left">
    <p>
    North Capital University(NCU) is a non-prfitable educational institute for giving higher and world class 
    education. The motive is to give better qualityful education.
    </p>

  </div>
</div>
</body>
</html>