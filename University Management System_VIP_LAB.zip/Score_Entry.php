<?php
$id="";
$opr="";
if(isset($_GET['opr']))
	$opr=$_GET['opr'];

if(isset($_GET['rs_id']))
	$id=$_GET['rs_id'];
	
						
if(isset($_POST['btn_sub'])){
	$stu_name=$_POST['sudenttxt'];
	$fa_name=$_POST['factxt'];
	$sub_name=$_POST['subjecttxt'];
	$miderm=$_POST['midermtxt'];
	$final=$_POST['finaltxt'];
	$note=$_POST['notetxt'];	
	

$sql_ins="INSERT INTO stu_score_tbl 
						VALUES(
							NULL,
							'$stu_name',
							'$fa_name' ,
							'$sub_name',
							'$miderm',
							'$final',
							'$note'
							)
					";
	
if($result = $mysqli->query($sql_ins))
{
    if($result->num_rows > 0)
	$msg="1 Row Inserted";
else
	$msg="Insert Error:".mysqli_error();
	
}
}	



if(isset($_POST['btn_upd'])){
	$stu_id=$_POST['sudenttxt'];
	$faculties_id =$_POST['factxt'];
	$sub_id=$_POST['subjecttxt'];
	$miderm=$_POST['midermtxt'];
	$final=$_POST['finaltxt'];
	$note=$_POST['notetxt'];
	
	$sql_update="UPDATE stu_score_tbl SET
							stu_id='$stu_id' ,
							faculties_id='$faculties_id' ,
							sub_id='$sub_id' ,
							miderm='$miderm' ,	
							final='$final' ,
							note='$note' 
						WHERE ss_id=$id

					";
		if($result1 = $mysqli->query($sql_update))
		{
			if($result1->num_rows > 0)
			header("location:?tag=view_scores");
		else
		$msg="Update Fail!...";	
		}
		}				

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>::. Build Bright University .::</title>
<link rel="stylesheet" type="text/css" href="css/style_entry.css" />
</head>

<body>
<?php
if($opr=="upd")
{
	$sql_upd="SELECT * FROM stu_score_tbl WHERE ss_id=$id";
	if($result2 = $mysqli->query($sql_upd))
		{
			if($result2->num_rows > 0)
			$rs_upd=mysqli_fetch_array($sql_upd);
		else
		$msg="No data preent.";	
		}
		}	
	
?>

	<div id="top_style">
        <div id="top_style_text">
      		Scores Update
        </div>
       <div id="top_style_button"> 
       		<form method="post">
            	<a href="?tag=view_scores"><input type="button" name="btn_view" value="Back" id="button_view" style="width:70px;"  /></a>
             
       		</form>
       </div>
</div>

<div id="style_informations">
	<form method="post">
    	<div>
    	<table border="0" cellpadding="5" cellspacing="0">
        	<tr>
            	<td>Students's Name</td>
            	<td>
                	<select name="sudenttxt" id="textbox">
                    	<option>---- Students's Name -----</option>
                            <?php
								  $student_name="SELECT * FROM stu_tbl";
								  if($result3 = $mysqli->query($student_name))
								  {
									  if($result3->num_rows > 0)
									 {
										while($row=$result3->fetch_array()){
											if($row['stu_id']==$rs_upd['stu_id'])
												  $iselect="selected";
										   else
											   $iselect="";
									 }
								     
									 } 
								  
							
								?>
                                <option value="<?php echo $row['stu_id'];?>" <?php echo $iselect ;?> > <?php echo $row['f_name']; echo" "; echo $row['l_name'];?> </option>
								<?php	
								}
                            ?>
                            
                    </select>
                </td>
            </tr>
            
            <tr>
            	<td>Facuties's Name</td>
            	<td>
                	<select name="factxt" id="textbox">
                    	<option>---- Facuries's Name   ------</option>
                            <?php
							   $fac_name=mysql_query("SELECT * FROM facuties_tbl");
							   if($result4 = $mysqli->query($fac_name))
							   {
								   if($result4->num_rows > 0)
								  {
									while($row=$result4->fetch_array()){
										if($row['faculties_id']==$rs_upd['faculties_id'])
											   $iselect="selected";
									else $iselect="";
								  }
							  
							   }
							   	
							 
								?>
                        		<option value="<?php echo $row['faculties_id'];?>" <?php echo $iselect ;?> > <?php echo $row['faculties_name'];?> </option>
                                <?php 
							   }
                            ?>
                    </select>
                </td>
            </tr>
            
            <tr>
            	<td>Subjects's Name</td>
            	<td>
                	<select name="subjecttxt" id="textbox">
                    	<option>------------ Sujects -----------</option>
                            <?php
							   $subject="SELECT * FROM sub_tbl";
							   
							   if($result5 = $mysqli->query($subject))
							   {
								   if($result5->num_rows > 0)
								  {
									while($row=$result5->fetch_array()){
										if($row['sub_id']==$rs_upd['sub_id'])
												$iselect="selected";
										 else
											 $iselect="";
								  }
							   	
							   
							   	
							  
							?>
                            <option value="<?php echo $row['sub_id'];?>" <?php echo $iselect ;?> > <?php echo $row['sub_name'];?> </option>
                            <?php	   
							   }
                            ?>
                    </select>
                </td>
            </tr>
            <tr>
            	<td>Miderm</td>
            	<td>
                	<input type="text" name="midermtxt" id="textbox" value="<?php echo $rs_upd['miderm'];?> "/>
                </td>
            </tr>
            
            <tr>
            	<td>Final</td>
                <td>
                	<input type="text" name="finaltxt"  id="textbox" value="<?php echo $rs_upd['final'];?>" />
                </td>
            </tr>
            
            <tr>
            	<td>Note</td>
                <td>
                	<textarea name="notetxt" cols="23" rows="3"><?php echo $rs_upd['note'];?></textarea>
                </td>
            </tr>
            
            <tr>
                <td colspan="2">
                	<input type="reset" value="Cancel" id="button-in"/>
                	<input type="submit" name="btn_upd" value="Update" id="button-in" title="Update"  />
                </td>
            </tr>
		</table>

   </div>
    </form>

</div>
<?php	
}
else
{
?>
	
    <div id="top_style">
        <div id="top_style_text">
      		Scores Entry
        </div>
       <div id="top_style_button"> 
       		<form method="post">
            	<a href="?tag=view_scores"><input type="button" name="btn_view" value="View_Scores" id="button_view" style="width:120px;"  /></a>
             
       		</form>
       </div>
</div>

<div id="style_informations">
	<form method="post">
    	<div>
    	<table border="0" cellpadding="5" cellspacing="0">
        	<tr>
            	<td>Students's Name</td>
            	<td>
                	<select name="sudenttxt" id="textbox">
                    	<option>---- Students's Name -----</option>
                            <?php
								  $student_name="SELECT * FROM stu_tbl";
								  $result3 = $mysqli->query($student_name);
								while($row=$result3->fetch_array()){
								?>
                                <option value="<?php echo $row['stu_id'];?>"> <?php echo $row['f_name']; echo" "; echo $row['l_name'];?> </option>
								<?php	
								}
                            ?>
                            
                    </select>
                </td>
            </tr>
            
            <tr>
            	<td>Facuties's Name</td>
            	<td>
                	<select name="factxt" id="textbox">
                    	<option>---- Facuries's Name   ------</option>
                            <?php
							   $fac_name="SELECT * FROM facuties_tbl";
							   $result3 = $mysqli->query($fac_name);
							   while($row=$result3->fetch_array()){
								?>
                        		<option value="<?php echo $row['faculties_id'];?>"> <?php echo $row['faculties_name'];?> </option>
                                <?php 
							   }
                            ?>
                    </select>
                </td>
            </tr>
            
            <tr>
            	<td>Subjects's Name</td>
            	<td>
                	<select name="subjecttxt" id="textbox">
                    	<option>------------ Sujects -----------</option>
                            <?php
							   $subject="SELECT * FROM sub_tbl";
							   $result3 = $mysqli->query($subject);
							   while($row=$result3->fetch_array()){
							?>
                            <option value="<?php echo $row['sub_id'];?>"> <?php echo $row['sub_name'];?> </option>
                            <?php	   
							   }
                            ?>
                    </select>
                </td>
            </tr>
            <tr>
            	<td>Miderm</td>
            	<td>
                	<input type="text" name="midermtxt" id="textbox" />
                </td>
            </tr>
            
            <tr>
            	<td>Final</td>
                <td>
                	<input type="text" name="finaltxt"  id="textbox" />
                </td>
            </tr>
            
            <tr>
            	<td>Note</td>
                <td>
                	<textarea name="notetxt" cols="23" rows="3"></textarea>
                </td>
            </tr>
            
            <tr>
                <td colspan="2">
                	<input type="reset" value="Cancel" id="button-in"/>
                	<input type="submit" name="btn_sub" value="Add Now" id="button-in"  />
                </td>
            </tr>
		</table>

   </div>
    </form>

</div>
<?php
}
?>
</body>
</html>