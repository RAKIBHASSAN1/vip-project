<?php
$mysqli = new mysqli('localhost', 'root', '', 'assignment');
	
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
?>