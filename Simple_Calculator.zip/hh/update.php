<?php
session_start();
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$mysqli = new mysqli("localhost", "root", "", "User");
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
echo "Connect Successfully. Host info: " . $mysqli->host_info;


if (isset($_POST['pupdate']))
{
    echo "shaiful";
    $myemail=$_POST['email'];
    $password=$_POST['password'];
    $ConfarmPassword=$_POST['new_password'];
    $sql="select * from info where email='$myemail' limit 1";
    echo'<br>';
    echo'<br>';
    echo "$sql";
    echo'<br>';
    echo "password= $password";
    echo'<br>';
    echo "Confarmpassword= $ConfarmPassword";
    echo'<br>';
    if($ConfarmPassword===$password)
    {
        echo "soman= $ConfarmPassword";
        echo'<br>';
        echo "myemail= $myemail";
        echo'<br>';
        $sql = "UPDATE info SET password ='$ConfarmPassword' WHERE email='$myemail' ";
        if($result = $mysqli->query($sql))
        {
            if($result->num_rows > 0)
            {
                echo "you have successfully login";
                $_SESSION[user]=$uname;
                header("location: home.html");
                echo "<br>";
                echo "shaiful";
    
            }
            else
            {
                echo "ssyou have not successfully login";
                header("location: sinup.php");
                
            
                
                
            }
        }
       
        echo "sql= $sql";
       // header("location: sinup.php");
        
    }
    
   

}

?>