<?php
session_start();
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$mysqli = new mysqli("localhost", "root", "", "User");
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
if (isset($_POST['sub']))
{
        
        echo "Connect Successfully. Host info: " . $mysqli->host_info;
        $a=$_POST['first_name'];
        $b=$_POST['last_name'];
        $c=$_POST['password'];
        $d=$_POST['user_name'];
        $e=$_POST['email'];


        if(!empty($a)&&!empty($b)&&!empty($c)&&!empty($d)&&!empty($e))
        {
            $sql = "INSERT INTO info (first_name, last_name,password,user_name,email) VALUES ('$a', '$b', '$c', '$d', '$e')";
            if($mysqli->query($sql) === true){
                // Obtain last inserted id
                $last_id = $mysqli->insert_id;
                echo "Records inserted successfully.";
                $_SESSION['ss'] = "Login successfully,Now you can visite our about page ";
                header("location: sinup.php");
                
            } else{
                echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
                
                header("location: join.html");
            }
        } 
}   



    $mysqli->close();
?>