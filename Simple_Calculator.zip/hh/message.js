<script>
function showAlert() {
  alert ("Hello world!");
}
</script>