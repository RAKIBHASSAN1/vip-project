function myclick(a)
{
   myform.display.value+=a;
}
function equal()
{
	myform.display.value=eval(myform.display.value);
}
function ac()
{
	myform.display.value=" ";
}
function backspace()
{
	var ss=myform.display.value;
	myform.display.value=ss.substr(0,ss.length-1);
}
function square()
{
	myform.display.value=Math.pow(myform.display.value,2);
}
function squart()
{
	myform.display.value=Math.pow(myform.display.value,1/2);
}-
p