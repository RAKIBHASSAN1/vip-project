var myvariable=document.querySelector(".login");
myvariable.onclick=function()
{
    
}
